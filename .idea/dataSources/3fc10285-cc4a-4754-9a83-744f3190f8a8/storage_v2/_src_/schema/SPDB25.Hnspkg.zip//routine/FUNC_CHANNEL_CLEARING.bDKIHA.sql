create function func_channel_clearing(startDate in varchar2,
                                                 endDate   in varchar2)
  RETURN varchar2 is
  msg            varchar(1024);
  compactCode    varchar(11); --序列号
  contactLine    varchar(12); --联行号
  accountName    varchar2(128); --账户名
  bankNumber     varchar(32); --银行卡号
  bankName       varchar(128); --开户行名称
  payeeAddress   varchar(128); --地址
  provinceCode   varchar(6);
  cityCode       varchar(6);
  provinceName   varchar(255);
  cityName       varchar(255);
  branchbankName varchar(256);
  sql0           varchar(1024);
  amount         number(20, 2);
  isBank         VARCHAR2(32);
  existAmount    number(12, 2);
  iCount         number(11);
  historyFee     number(20, 2);
  channelId      varchar2(32);
  channelName    varchar2(256);
  ---------------------
  total_netfee     number(20, 2); --日结历史表中的交易净额
  total_count      number(20); --交易笔数
  accountType      varchar2(12);
  md5_str          varchar2(2000);
  enterpriseSerial varchar2(64);
  cleaningMode     varchar2(6);
  bankChannelId    varchar2(128);
  otherBankChannelId varchar2(128);
  merchantFee        number(20, 2);
  merchantCleaningId number(20);

  v_merchant_fee   number(20, 2);
  v_a_merchant_fee number(20, 2);
  v_sum_third_fee  number(20, 2);
  cleanDate        varchar2(128);
  CURSOR cur_01 IS
    select channel_id,
           sum(total_count) total_count,
           sum(total_netfee) as total_netfee,
           sum(total_benefit_fee) as benefit_fee,
           sum(a_total_benefit_fee) as a_benefit_fee,
           to_char(pay_date, 'yyyy-MM-dd') as pay_date
      from pf_channel_benefit_stat
     where channel_id not in
           (select channel_id
              from pf_channel_info
             where invite_code = '000000'
                or parent_invite_code = '0'
                or channel_id in
                   (select param_value
                      from pf_interface_param_info a
                      left join pf_interface_info b
                        on a.interface_id = b.interface_id
                     where interface_code = 'OTHER_BANK_CHANNEL_ID'))
       and to_char(pay_date, 'yyyy-MM-dd') between startDate and endDate
     group by channel_id, to_char(pay_date, 'yyyy-MM-dd');

  --银行渠道必须为所有银行渠道的和
  CURSOR cur_03 IS
    select sum(total_count) total_count,
           sum(total_netfee) as total_netfee,
           sum(total_benefit_fee) as benefit_fee,
           sum(a_total_benefit_fee) as a_benefit_fee,
           to_char(pay_date, 'yyyy-MM-dd') as pay_date
      from pf_channel_benefit_stat
     where channel_id in
           (select param_value
              from pf_interface_param_info a
              left join pf_interface_info b
                on a.interface_id = b.interface_id
             where interface_code = 'OTHER_BANK_CHANNEL_ID')
       and to_char(pay_date, 'yyyy-MM-dd') between startDate and endDate
     group by to_char(pay_date, 'yyyy-MM-dd');

  --威富通的改为直接从pf_channel_benefit_stat统计银行平台和威富通
  CURSOR cur_02 IS
    select sum(total_count) total_count,
           sum(total_netfee) as total_netfee,
           sum(total_benefit_fee) as benefit_fee,
           sum(a_total_benefit_fee) as a_benefit_fee,
           to_char(pay_date, 'yyyy-MM-dd') as pay_date
      from pf_channel_benefit_stat
     where channel_id in (select channel_id
                            from pf_channel_info
                           where invite_code = '000000'
                              or parent_invite_code = '0')
       and to_char(pay_date, 'yyyy-MM-dd') between startDate and endDate
     group by to_char(pay_date, 'yyyy-MM-dd');

begin
  msg := 'success';
  begin
    sql0 := 'select interface_address from pf_interface_info where interface_code=''CLEANING_MODE''';
    execute immediate sql0
      into cleaningMode;
  exception
    when NO_DATA_FOUND then
      msg := 'Can''t find cleaning mode,please configure CLEANING_MODE!';
      return msg;
  end;
  --查询银行渠道编号
  begin
    sql0 := 'select interface_address from pf_interface_info where interface_code=''BANK_CHANNEL_ID''';
    execute immediate sql0
      into bankChannelId;
  exception
    when NO_DATA_FOUND then
      msg := 'Can''t find cleaning mode,please configure BANK_CHANNEL_ID!';
      return msg;
  end;

  --查询其他银行渠道编号
  begin
    sql0 := 'select interface_address from pf_interface_info where interface_code=''OTHER_BANK_CHANNEL_ID''';
    execute immediate sql0
      into otherBankChannelId;
  exception
    when NO_DATA_FOUND then
      msg := 'Can''t find cleaning mode,please configure OTHER_BANK_CHANNEL_ID!';
      return msg;
  end;

  for rec01 in cur_01 loop

    --获取渠道基本信息
    begin
      sql0 := 'select a.is_bank ,a.account_type,c.channel_name,a.contact_line,a.account_name,a.bank_number,b.bank_name,a.province,a.city,a.bank_name
              from pf_channel_account_info a left join pf_bank_info b on a.bank_number_code=b.bank_number_code
              left join pf_channel_info c on a.channel_id=c.channel_id
              where a.channel_id=' || '''' || rec01.channel_id || '''';
      execute immediate sql0
        into isBank, accountType, channelName, contactLine, accountName, bankNumber, bankName, provinceCode, cityCode, branchbankName;
    exception
      when NO_DATA_FOUND then
        msg := '没有在渠道账号表找到渠道号为' || rec01.channel_id || '的账号信息';
        return msg;
    end;
    select name
      into provinceName
      from shop_city_area
     where region_id = provinceCode;
    select name
      into cityName
      from shop_city_area
     where region_id = cityCode;
    payeeAddress := bankName || provinceName || cityName || branchbankName;
    select rpad(round(dbms_random.value(1,
                                        (SYSDATE -
                                        TO_DATE('1970-1-1 8',
                                                 'YYYY-MM-DD HH24')) *
                                        86400000 +
                                        TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3),
                                                          'FF')))),
                11,
                0)
      into compactCode
      FROM DUAL;

    select count(1)
      into iCount
      from pf_merchant_cleaning_info
     where to_char(pay_date, 'yyyy-MM-dd') = rec01.pay_date
       and merchant_code = rec01.channel_id
       and is_channel = 'CLR001';
    --如果不存在则需要插入
    if (iCount = 0) then
      if (cleaningMode = 'CLR001') then
        amount := rec01.a_benefit_fee;
      else
        amount := rec01.benefit_fee;
      end if;
    else
      existAmount := 0;
      --存在已清分的，先统计已清分除去的的清分金额
      select count(1)
        into iCount
        from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') = rec01.pay_date
         and merchant_code = rec01.channel_id
         and is_channel = 'CLR001'
         and upper(flag) = 'Y';
      if (iCount > 0) then
        select amount
          into existAmount
          from pf_merchant_cleaning_info
         where to_char(pay_date, 'yyyy-MM-dd') = rec01.pay_date
           and merchant_code = rec01.channel_id
           and is_channel = 'CLR001'
           and upper(flag) = 'Y';
      end if;
      --删除原有的
      delete from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') = rec01.pay_date
         and merchant_code = rec01.channel_id
         and is_channel = 'CLR001'
         and upper(flag) != 'Y';
      if (cleaningMode = 'CLR001') then
        amount := rec01.a_benefit_fee - existAmount;
      else
        amount := rec01.benefit_fee - existAmount;
      end if;
    end if;
    if (amount < 0) then
      select channel_name
        into channelName
        from pf_channel_info
       where channel_id = rec01.channel_id;
      msg := 'Exception:channelName:' || channelName ||
             ' cleaning amount less then 0';
      exit;
    end if;
    if (amount = 0) then
      continue;
    end if;
    md5_str := md5(contactLine || bankNumber || accountName || payeeAddress);
    select sys_guid() into enterpriseSerial from dual;
    select PF_MERCHANT_CLEANING_INFO_seq.nextval
      into merchantCleaningId
      from dual;
    msg := func_c_cleaning_date_stat(to_date(rec01.pay_date, 'yyyy-MM-dd'),
                                     1,
                                     'SPDB_GUANGZHOU',
                                     cleanDate);
    if (msg <> 'success') then
      return msg;
    end if;
    sql0 := 'insert into PF_MERCHANT_CLEANING_INFO(id,pay_date,compact_code,merchant_code,
          contact_line,account_name,account,bank_name,amount,flag,transaction_filename,is_channel,update_version,total_netfee,total_count,clean_status,cleaning_date,account_type,md5_str,is_update,enterprise_serial,is_bank,remark)
          values(' || merchantCleaningId || ',' ||
            'TO_TIMESTAMP(''' || rec01.pay_date || ' 00:00:00.000000000''' ||
            ', ''YYYY-MM-DD HH24:MI:SS.FF'')' || ',' || '''' || compactCode || '''' || ',' || '''' ||
            rec01.channel_id || '''' || ',' || '''' || contactLine || '''' || ',' || '''' ||
            accountName || '''' || ',' || '''' || bankNumber || '''' || ',' || '''' ||
            payeeAddress || '''' || ',' || '''' || to_char(amount) || '''' ||
            ',''X'',null,''CLR001'',0,' || to_char(rec01.total_netfee) || ',' ||
            rec01.total_count || ',''CLEAN_000'',to_date(''' || cleanDate ||
            ''',''yyyy-MM-dd''),''' || accountType || ''',''' || md5_str ||
            ''',0,''' || enterpriseSerial || ''',''' || isBank ||
            ''',''移动支付' ||
            to_char(to_date(rec01.pay_date, 'yyyy-MM-dd'), 'yyyyMMdd') ||
            ''')';
    execute immediate sql0;
  end loop;

  --银行渠道的基本账号信息
  select a.is_bank,
         a.account_type,
         a.contact_line,
         a.account_name,
         a.bank_number,
         b.bank_name,
         a.province,
         a.city,
         a.bank_name
    into isBank,
         accountType,
         contactLine,
         accountName,
         bankNumber,
         bankName,
         provinceCode,
         cityCode,
         branchbankName
    from pf_channel_account_info a
    left join pf_bank_info b
      on a.bank_number_code = b.bank_number_code
   where channel_id = bankChannelId;

  select name
    into provinceName
    from shop_city_area
   where region_id = provinceCode;
  select name into cityName from shop_city_area where region_id = cityCode;
  payeeAddress := bankName || provinceName || cityName || branchbankName;

  select channel_id, channel_name
    into channelId, channelName
    from pf_channel_info
   where channel_id = bankChannelId;

  --下面按天来进行计算银行渠道的总和
  for rec03 in cur_03 loop
    SELECT rpad(round(dbms_random.value(1,
                                        (SYSDATE -
                                        TO_DATE('1970-1-1 8',
                                                 'YYYY-MM-DD HH24')) *
                                        86400000 +
                                        TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3),
                                                          'FF')))),
                11,
                0)
      into compactCode
      FROM DUAL;

    select count(1)
      into iCount
      from pf_merchant_cleaning_info
     where to_char(pay_date, 'yyyy-MM-dd') = rec03.pay_date
       and merchant_code = bankChannelId
       and is_channel = 'CLR001';
    if (iCount = 0) then
      if (cleaningMode = 'CLR001') then
        amount := rec03.a_benefit_fee;
      else
        amount := rec03.benefit_fee;
      end if;
    else
      existAmount := 0;
      --存在已清分的，先统计已清分除去的的清分金额
      select count(1)
        into iCount
        from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') = rec03.pay_date
         and merchant_code = bankChannelId
         and is_channel = 'CLR001'
         and upper(flag) = 'Y';
      if (iCount > 0) then
        select amount
          into existAmount
          from pf_merchant_cleaning_info
         where to_char(pay_date, 'yyyy-MM-dd') = rec03.pay_date
           and merchant_code = bankChannelId
           and is_channel = 'CLR001'
           and upper(flag) = 'Y';
      end if;
      --删除原有的
      delete from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') = rec03.pay_date
         and merchant_code = bankChannelId
         and is_channel = 'CLR001'
         and upper(flag) != 'Y';
      if (cleaningMode = 'CLR001') then
        amount := rec03.a_benefit_fee - existAmount;
      else
        amount := rec03.benefit_fee - existAmount;
      end if;
    end if;
    if (amount < 0) then
      msg := 'Exception:channelName:' || channelName ||
             ' cleaning amount less then 0';
      exit;
    end if;
    if (amount = 0) then
      continue;
    end if;
    md5_str := md5(contactLine || bankNumber || accountName || payeeAddress);
    select sys_guid() into enterpriseSerial from dual;
    msg := func_c_cleaning_date_stat(to_date(rec03.pay_date, 'yyyy-MM-dd'),
                                     1,
                                     'SPDB_GUANGZHOU',
                                     cleanDate);
    if (msg <> 'success') then
      return msg;
    end if;

    --银行清分记录更新商户手续费字段
      select sum(nvl(merchant_fee, 0)), sum(nvl(a_merchant_fee, 0))
        into v_merchant_fee, v_a_merchant_fee
        from pf_pay_day_bill_history w
       where
       to_char(w.pay_date, 'yyyy-MM-dd') = rec03.pay_date;
      if (cleaningMode = 'CLR001') then
        merchantFee := v_a_merchant_fee;
      else
        merchantFee := v_merchant_fee;
      end if;

    sql0 := 'insert into PF_MERCHANT_CLEANING_INFO(id,pay_date,compact_code,merchant_code,
              contact_line,account_name,account,bank_name,amount,flag,transaction_filename,is_channel,update_version,total_netfee,total_count,clean_status,cleaning_date,account_type,md5_str,is_update,enterprise_serial,is_bank,remark,merchant_fee)
              values(PF_MERCHANT_CLEANING_INFO_seq.nextval,' ||
            'TO_TIMESTAMP(''' || rec03.pay_date || ' 00:00:00.000000000''' ||
            ', ''YYYY-MM-DD HH24:MI:SS.FF'')' || ',' || '''' || compactCode || '''' ||
            ',''' || bankChannelId || ''',' || '''' || contactLine || '''' || ',' || '''' ||
            accountName || '''' || ',' || '''' || bankNumber || '''' || ',' || '''' ||
            payeeAddress || '''' || ',' || '''' || to_char(amount) || '''' ||
            ',''X'',null,''CLR001'',0,' || to_char(rec03.total_netfee) || ',' ||
            rec03.total_count || ',''CLEAN_000'',to_date(''' || cleanDate ||
            ''',''yyyy-MM-dd''),''' || accountType || ''',''' || md5_str ||
            ''',0,''' || enterpriseSerial || ''',''' || isBank ||
            ''',''移动支付' ||
            to_char(to_date(rec03.pay_date, 'yyyy-MM-dd'), 'yyyyMMdd') ||
            ''',' || to_char(merchantFee) || ')';
    execute immediate sql0;

  end loop;

  --如果银行没有分润还是得插入一条数据
  begin
    select count(1), amount
      into iCount, historyFee
      from pf_merchant_cleaning_info
     where to_char(pay_date, 'yyyy-MM-dd') = startDate
       and merchant_code = bankChannelId
       and is_channel = 'CLR001'
     group by amount;
    if (iCount != 0 and historyFee = 0) then
      delete from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') = startDate
         and merchant_code = bankChannelId
         and is_channel = 'CLR001';
    end if;
  exception
    when NO_DATA_FOUND then
      null;
    When others then
      msg := SUBSTR(SQLERRM, 1, 200);
      rollback;
      return msg;
  end;

  select count(1)
    into iCount
    from pf_merchant_cleaning_info
   where to_char(pay_date, 'yyyy-MM-dd') = startDate
     and merchant_code = bankChannelId
     and is_channel = 'CLR001';
  if (iCount = 0) then
    begin
      sql0 := 'select a.is_bank ,a.account_type,c.channel_name,a.contact_line,a.account_name,a.bank_number,b.bank_name,a.province,a.city,a.bank_name
              from pf_channel_account_info a left join pf_bank_info b on a.bank_number_code=b.bank_number_code
              left join pf_channel_info c on a.channel_id=c.channel_id
              where a.channel_id=' || '''' || bankChannelId || '''';
      execute immediate sql0
        into isBank, accountType, channelName, contactLine, accountName, bankNumber, bankName, provinceCode, cityCode, branchbankName;
    exception

      when NO_DATA_FOUND then
        msg := '没有在渠道账号表找到渠道号为' || bankChannelId || '的账号信息';
        return msg;
    end;
    select rpad(round(dbms_random.value(1,
                                        (SYSDATE -
                                        TO_DATE('1970-1-1 8',
                                                 'YYYY-MM-DD HH24')) *
                                        86400000 +
                                        TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3),
                                                          'FF')))),
                11,
                0)
      into compactCode
      FROM DUAL;
    payeeAddress := bankName || provinceName || cityName || branchbankName;
    msg          := func_c_cleaning_date_stat(to_date(startDate,
                                                      'yyyy-MM-dd'),
                                              1,
                                              'SPDB_GUANGZHOU',
                                              cleanDate);
    if (msg <> 'success') then
      return msg;
    end if;
    md5_str := md5(contactLine || bankNumber || accountName || payeeAddress);
    select sys_guid() into enterpriseSerial from dual;
    select sum(nvl(merchant_fee, 0)), sum(nvl(a_merchant_fee, 0))
      into v_merchant_fee, v_a_merchant_fee
      from pf_pay_day_bill_history w
     where
    /*w.merchant_code in
        (select a.merchant_code
           from pf_merchant_info a
          where a.channel_id = bankChannelId)
    and */
     to_char(w.pay_date, 'yyyy-MM-dd') = startDate;
    if (cleaningMode = 'CLR001') then
      merchantFee := v_a_merchant_fee;
    else
      merchantFee := v_merchant_fee;
    end if;
    sql0 := 'insert into PF_MERCHANT_CLEANING_INFO(id,pay_date,compact_code,merchant_code,
          contact_line,account_name,account,bank_name,amount,flag,transaction_filename,is_channel,update_version,total_netfee,total_count,clean_status,cleaning_date,account_type,md5_str,is_update,enterprise_serial,is_bank,merchant_fee,remark)
          values(PF_MERCHANT_CLEANING_INFO_seq.nextval,' ||
            'TO_TIMESTAMP(''' || startDate || ' 00:00:00.000000000''' ||
            ', ''YYYY-MM-DD HH24:MI:SS.FF'')' || ',' || '''' || compactCode || '''' || ',' || '''' ||
            bankChannelId || '''' || ',' || '''' || contactLine || '''' || ',' || '''' ||
            accountName || '''' || ',' || '''' || bankNumber || '''' || ',' || '''' ||
            payeeAddress || '''' || ',' ||
            '0,''X'',null,''CLR001'',0,0,0,''CLEAN_000'',to_date(''' ||
            cleanDate || ''',''yyyy-MM-dd''),''' || accountType || ''',''' ||
            md5_str || ''',0,''' || enterpriseSerial || ''',''' || isBank ||
            ''',' || to_char(merchantFee) || ',''移动支付' ||
            to_char(to_date(startDate, 'yyyy-MM-dd'), 'yyyyMMdd') || ''')';
    execute immediate sql0;
  end if;

  --威富通的基本账号信息
  select a.is_bank,
         a.account_type,
         a.contact_line,
         a.account_name,
         a.bank_number,
         b.bank_name,
         a.province,
         a.city,
         a.bank_name
    into isBank,
         accountType,
         contactLine,
         accountName,
         bankNumber,
         bankName,
         provinceCode,
         cityCode,
         branchbankName
    from pf_channel_account_info a
    left join pf_bank_info b
      on a.bank_number_code = b.bank_number_code
   where channel_id = (select channel_id
                         from pf_channel_info
                        where invite_code = '000000');

  select name
    into provinceName
    from shop_city_area
   where region_id = provinceCode;
  select name into cityName from shop_city_area where region_id = cityCode;
  payeeAddress := bankName || provinceName || cityName || branchbankName;

  select channel_id, channel_name
    into channelId, channelName
    from pf_channel_info
   where invite_code = '000000';

  --下面按天来进行计算威富通的总和
  for rec02 in cur_02 loop
    SELECT rpad(round(dbms_random.value(1,
                                        (SYSDATE -
                                        TO_DATE('1970-1-1 8',
                                                 'YYYY-MM-DD HH24')) *
                                        86400000 +
                                        TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3),
                                                          'FF')))),
                11,
                0)
      into compactCode
      FROM DUAL;
    select count(1)
      into iCount
      from pf_merchant_cleaning_info
     where to_char(pay_date, 'yyyy-MM-dd') = rec02.pay_date
       and merchant_code =
           (select channel_id
              from pf_channel_info w
             where w.invite_code = '000000')
       and is_channel = 'CLR001';
    if (iCount = 0) then
      if (cleaningMode = 'CLR001') then
        amount := rec02.a_benefit_fee;
      else
        amount := rec02.benefit_fee;
      end if;
    else
      existAmount := 0;
      --存在已清分的，先统计已清分除去的的清分金额
      select count(1)
        into iCount
        from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') = rec02.pay_date
         and merchant_code =
             (select channel_id
                from pf_channel_info w
               where w.invite_code = '000000')
         and is_channel = 'CLR001'
         and upper(flag) = 'Y';
      if (iCount > 0) then
        select amount
          into existAmount
          from pf_merchant_cleaning_info
         where to_char(pay_date, 'yyyy-MM-dd') = rec02.pay_date
           and merchant_code =
               (select channel_id
                  from pf_channel_info w
                 where w.invite_code = '000000')
           and is_channel = 'CLR001'
           and upper(flag) = 'Y';
      end if;
      --删除原有的
      delete from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') = rec02.pay_date
         and merchant_code =
             (select channel_id
                from pf_channel_info w
               where w.invite_code = '000000')
         and is_channel = 'CLR001'
         and upper(flag) != 'Y';
      if (cleaningMode = 'CLR001') then
        amount := rec02.a_benefit_fee - existAmount;
      else
        amount := rec02.benefit_fee - existAmount;
      end if;
    end if;
    if (amount < 0) then
      select channel_name
        into channelName
        from pf_channel_info
       where channel_id = (select channel_id
                             from pf_channel_info w
                            where w.invite_code = '000000');
      msg := 'Exception:channelName:' || channelName ||
             ' cleaning amount less then 0';
      exit;
    end if;
    if (amount = 0) then
      continue;
    end if;
    md5_str := md5(contactLine || bankNumber || accountName || payeeAddress);
    select sys_guid() into enterpriseSerial from dual;
    msg := func_c_cleaning_date_stat(to_date(rec02.pay_date, 'yyyy-MM-dd'),
                                     1,
                                     'SPDB_GUANGZHOU',
                                     cleanDate);
    if (msg <> 'success') then
      return msg;
    end if;
    sql0 := 'insert into PF_MERCHANT_CLEANING_INFO(id,pay_date,compact_code,merchant_code,
              contact_line,account_name,account,bank_name,amount,flag,transaction_filename,is_channel,update_version,total_netfee,total_count,clean_status,cleaning_date,account_type,md5_str,is_update,enterprise_serial,is_bank,remark)
              values(PF_MERCHANT_CLEANING_INFO_seq.nextval,' ||
            'TO_TIMESTAMP(''' || rec02.pay_date || ' 00:00:00.000000000''' ||
            ', ''YYYY-MM-DD HH24:MI:SS.FF'')' || ',' || '''' || compactCode || '''' ||
            ',''SPDB_GUANGZHOU_222222'',' || '''' || contactLine || '''' || ',' || '''' ||
            accountName || '''' || ',' || '''' || bankNumber || '''' || ',' || '''' ||
            payeeAddress || '''' || ',' || '''' || to_char(amount) || '''' ||
            ',''X'',null,''CLR001'',0,' || to_char(rec02.total_netfee) || ',' ||
            rec02.total_count || ',''CLEAN_000'',to_date(''' || cleanDate ||
            ''',''yyyy-MM-dd''),''' || accountType || ''',''' || md5_str ||
            ''',0,''' || enterpriseSerial || ''',''' || isBank ||
            ''',''移动支付' ||
            to_char(to_date(rec02.pay_date, 'yyyy-MM-dd'), 'yyyyMMdd') ||
            ''')';
    execute immediate sql0;

  end loop;
  --财付通手续费
  select sum(nvl(third_fee, 0)), sum(nvl(total_netfee, 0))
    into v_sum_third_fee, merchantFee
    from pf_pay_day_bill_history
   where to_char(pay_date, 'yyyy-MM-dd') between startDate and endDate;
  if (v_sum_third_fee is null) then
    v_sum_third_fee := 0.0;
  end if;
  if (merchantFee is null) then
    merchantFee := 0.0;
  end if;
  delete from pf_merchant_cleaning_info w
   where w.is_channel = 'CLR003'
     and to_char(w.pay_date, 'yyyy-MM-dd') between startDate and endDate;
  md5_str := md5('CFT' || 'CFT' || 'CFT' || 'CFT');
  select sys_guid() into enterpriseSerial from dual;
  msg := func_c_cleaning_date_stat(to_date(startDate, 'yyyy-MM-dd'),
                                   1,
                                   'SPDB_GUANGZHOU',
                                   cleanDate);
  if (msg <> 'success') then
    return msg;
  end if;
  sql0 := 'insert into PF_MERCHANT_CLEANING_INFO(id,pay_date,merchant_code,
              amount,flag,is_channel,update_version,clean_status,cleaning_date,md5_str,is_update,enterprise_serial,merchant_fee)
              values(PF_MERCHANT_CLEANING_INFO_seq.nextval,' ||
          'TO_TIMESTAMP(''' || startDate || ' 00:00:00.000000000''' ||
          ', ''YYYY-MM-DD HH24:MI:SS.FF'')' || ',''CFT'',' ||
          to_char(v_sum_third_fee) ||
          ',''X'',''CLR003'',0,''CLEAN_000'',to_date(''' || cleanDate ||
          ''',''yyyy-MM-dd''),''' || md5_str || ''',0,''' ||
          enterpriseSerial || ''',' || to_char(merchantFee) || ')';
  execute immediate sql0;

  return msg;
Exception
  When others then
    msg := SUBSTR(SQLERRM, 1, 200);
    rollback;
    return msg;
end func_channel_clearing;






/

