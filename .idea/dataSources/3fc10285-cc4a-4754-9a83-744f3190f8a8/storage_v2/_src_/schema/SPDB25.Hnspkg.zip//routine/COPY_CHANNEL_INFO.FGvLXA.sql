create procedure copy_channel_info(msg out varchar2) is
 --channelRowType pf_channel_info%rowtype;
  channelIdChar        number(6);
  inviteCodeChar       number(6);
  iCount               number(1);
  parentInviteCodeChar varchar2(6);
  userName             varchar2(32);
  subjectId            number(11);
  cursor cursor01 is
    select *
      from pf_channel_info a
     where a.channel_id != 'SPDB_GUANGZHOU_516539'
     start with a.channel_id = 'SPDB_GUANGZHOU_516539'
    connect by prior a.invite_code = a.parent_invite_code
     order by level;
begin
  --重复执行删除上次执行插入的数据
  --用户相关的表
  delete from admin_operator_user a
   where a.username in
         (select w.user_name
            from PF_USER_INFO w
           where w.channel_id in
                 (select channel_id
                    from pf_channel_info a
                   start with a.channel_id = 'SPDB_GUANGZHOU_777777'
                  connect by prior a.invite_code = a.parent_invite_code));

  delete from rbac_subject_role_ref a
   where a.subject_id in
         (select c.id
            from rbac_subject_user c
           where c.username in
                 (select w.user_name
                    from PF_USER_INFO w
                   where w.channel_id in
                         (select channel_id
                            from pf_channel_info a
                           start with a.channel_id = 'SPDB_GUANGZHOU_777777'
                          connect by prior a.invite_code = a.parent_invite_code)));

  delete from rbac_subject_user c
   where c.username in
         (select w.user_name
            from PF_USER_INFO w
           where w.channel_id in
                 (select channel_id
                    from pf_channel_info a
                   start with a.channel_id = 'SPDB_GUANGZHOU_777777'
                  connect by prior a.invite_code = a.parent_invite_code));

  delete from PF_USER_INFO w
   where w.channel_id in
         (select channel_id
            from pf_channel_info a
           start with a.channel_id = 'SPDB_GUANGZHOU_777777'
          connect by prior a.invite_code = a.parent_invite_code);

  delete from pf_channel_account_info w
   where w.channel_id in
         (select channel_id
            from pf_channel_info a
           start with a.channel_id = 'SPDB_GUANGZHOU_777777'
          connect by prior a.invite_code = a.parent_invite_code);

  delete from pf_channel_rate_info w
   where w.channel_id in
         (select channel_id
            from pf_channel_info a
           start with a.channel_id = 'SPDB_GUANGZHOU_777777'
          connect by prior a.invite_code = a.parent_invite_code);

  delete from pf_channel_info w
   where w.channel_id in
         (select channel_id
            from pf_channel_info a
           start with a.channel_id = 'SPDB_GUANGZHOU_777777'
          connect by prior a.invite_code = a.parent_invite_code);

  select ceil(dbms_random.value(100000, 999999))
    into channelIdChar
    from dual;
  inviteCodeChar := channelIdChar;

  --先插入一个一级渠道 广州分行2
  userName := 'sp2_777777';
  --复制渠道
  insert into pf_channel_info
    (id,
     channel_id,
     channel_name,
     status,
     examine_status,
     create_time,
     parent_invite_code,
     invite_code,
     examine_time,
     status_remark,
     examine_remark,
     province,
     city,
     country,
     industry,
     photo,
     address,
     username,
     phone,
     email,
     remark,
     update_version)
    select pf_channel_info_seq.nextval,
           'SPDB_GUANGZHOU_777777',
           channel_name || '2',
           status,
           examine_status,
           create_time,
           parent_invite_code,
           '777777',
           examine_time,
           status_remark,
           examine_remark,
           province,
           city,
           country,
           industry,
           photo,
           address,
           username,
           phone,
           email,
           remark,
           update_version
      from pf_channel_info w
     where w.channel_id = 'SPDB_GUANGZHOU_516539';

  insert into pf_channel_account_info
    (id,
     channel_id,
     account_type,
     account_name,
     account_identity,
     contact_line,
     bank_number_code,
     bank_number,
     province,
     city,
     bank_name,
     update_version,
     create_date,
     channel_type,
     is_bank)
    select pf_channel_account_info_seq.nextval,
           'SPDB_GUANGZHOU_777777',
           account_type,
           account_name,
           account_identity,
           contact_line,
           bank_number_code,
           bank_number,
           province,
           city,
           bank_name,
           update_version,
           create_date,
           channel_type,
           is_bank
      from pf_channel_account_info w
     where w.channel_id = 'SPDB_GUANGZHOU_516539';

  insert into pf_channel_rate_info
    (id,
     pay_id,
     channel_id,
     type,
     pay_mode,
     pay_name,
     rate_type,
     rate,
     status,
     remark,
     update_version,
     create_date)
    select pf_channel_rate_info_seq.nextval,
           pay_id,
           'SPDB_GUANGZHOU_777777',
           type,
           pay_mode,
           pay_name,
           rate_type,
           rate,
           status,
           remark,
           update_version,
           create_date
      from pf_channel_rate_info w
     where w.channel_id = 'SPDB_GUANGZHOU_516539';

  insert into PF_USER_INFO
    (id,
     channel_id,
     user_name,
     user_pwd,
     phone,
     add_time,
     is_operator,
     remark,
     update_version)
  values
    (PF_USER_INFO_seq.nextval,
     'SPDB_GUANGZHOU_777777',
     userName,
     '123456',
     '13265443456',
     sysdate,
     'OPR000',
     '',
     1);
  insert into admin_operator_user
    (id,
     username,
     domain_id,
     realname,
     deptname,
     phone,
     qq,
     remark,
     created_at,
     created_by,
     enabled,
     is_delete,
     update_version)
  values
    (admin_operator_user_seq.nextval,
     userName,
     61,
     null,
     null,
     null,
     null,
     null,
     sysdate,
     '1',
     1,
     0,
     1);

  select rbac_subject_user_seq.nextval into subjectId from dual;

  insert into rbac_subject_user
    (id,
     created_at,
     created_by,
     updated_at,
     updated_by,
     username,
     domain_id,
     password,
     enabled,
     update_version)
  values
    (subjectId,
     sysdate,
     null,
     null,
     null,
     userName,
     61,
     '3b1ebd28a439664eee0efcbd7b88d862',
     1,
     1);
  insert into rbac_subject_role_ref
    (subject_id, role_id)
  values
    (subjectId, 3);

  for rec01 in cursor01 loop
    --每次进来初始化
    select ceil(dbms_random.value(100000, 999999))
      into channelIdChar
      from dual;
    select ceil(dbms_random.value(100000, 999999))
      into inviteCodeChar
      from dual;
    --随机生成不重复的渠道ID
    select count(1)
      into iCount
      from pf_channel_info w
     where w.channel_id = 'SPDB_GUANGZHOU_' || channelIdChar;

    while (iCount <> 0) loop
      select ceil(dbms_random.value(100000, 999999))
        into channelIdChar
        from dual;
      select count(1)
        into iCount
        from pf_channel_info w
       where w.channel_id = 'SPDB_GUANGZHOU_' || channelIdChar;
    end loop;
    --生成不重复的渠道邀请码
    select count(1)
      into iCount
      from pf_channel_info w
     where w.invite_code = inviteCodeChar || '';

    while (iCount <> 0) loop
      select ceil(dbms_random.value(100000, 999999))
        into inviteCodeChar
        from dual;
      select count(1)
        into iCount
        from pf_channel_info w
       where w.invite_code = to_char(inviteCodeChar);
    end loop;
    userName := 'sp2_' || inviteCodeChar;
    --找父级邀请码

    select invite_code
      into parentInviteCodeChar
      from pf_channel_info c
     where c.channel_name =
           (select a.channel_name || '2'
              from pf_channel_info a
             where a.invite_code =
                   (select parent_invite_code
                      from pf_channel_info w
                     where w.channel_name = rec01.channel_name));

    --插入渠道信息
    insert into pf_channel_info
      (id,
       channel_id,
       channel_name,
       status,
       examine_status,
       create_time,
       parent_invite_code,
       invite_code,
       examine_time,
       status_remark,
       examine_remark,
       province,
       city,
       country,
       industry,
       photo,
       address,
       username,
       phone,
       email,
       remark,
       update_version)
      select pf_channel_info_seq.nextval,
             'SPDB_GUANGZHOU_' || channelIdChar,
             rec01.channel_name || '2',
             rec01.status,
             rec01.examine_status,
             rec01.create_time,
             parentInviteCodeChar,
             to_char(inviteCodeChar),
             rec01.examine_time,
             rec01.status_remark,
             rec01.examine_remark,
             rec01.province,
             rec01.city,
             rec01.country,
             rec01.industry,
             rec01.photo,
             rec01.address,
             rec01.username,
             rec01.phone,
             rec01.email,
             rec01.remark,
             rec01.update_version
        from dual;

    insert into pf_channel_account_info
      (id,
       channel_id,
       account_type,
       account_name,
       account_identity,
       contact_line,
       bank_number_code,
       bank_number,
       province,
       city,
       bank_name,
       update_version,
       create_date,
       channel_type,
       is_bank)
      select pf_channel_account_info_seq.nextval,
             'SPDB_GUANGZHOU_' || channelIdChar,
             account_type,
             account_name,
             account_identity,
             contact_line,
             bank_number_code,
             bank_number,
             province,
             city,
             bank_name,
             update_version,
             create_date,
             channel_type,
             is_bank
        from pf_channel_account_info w
       where w.channel_id = rec01.channel_id;

    insert into pf_channel_rate_info
      (id,
       pay_id,
       channel_id,
       type,
       pay_mode,
       pay_name,
       rate_type,
       rate,
       status,
       remark,
       update_version,
       create_date)
      select pf_channel_rate_info_seq.nextval,
             pay_id,
             'SPDB_GUANGZHOU_' || channelIdChar,
             type,
             pay_mode,
             pay_name,
             rate_type,
             rate,
             status,
             remark,
             update_version,
             create_date
        from pf_channel_rate_info w
       where w.channel_id = rec01.channel_id;

    insert into PF_USER_INFO
      (id,
       channel_id,
       user_name,
       user_pwd,
       phone,
       add_time,
       is_operator,
       remark,
       update_version)
    values
      (PF_USER_INFO_seq.nextval,
       'SPDB_GUANGZHOU_777777',
       userName,
       '123456',
       '13265443456',
       sysdate,
       'OPR000',
       '',
       1);
    insert into admin_operator_user
      (id,
       username,
       domain_id,
       realname,
       deptname,
       phone,
       qq,
       remark,
       created_at,
       created_by,
       enabled,
       is_delete,
       update_version)
    values
      (admin_operator_user_seq.nextval,
       userName,
       61,
       null,
       null,
       null,
       null,
       null,
       sysdate,
       '1',
       1,
       0,
       1);

    select rbac_subject_user_seq.nextval into subjectId from dual;

    insert into rbac_subject_user
      (id,
       created_at,
       created_by,
       updated_at,
       updated_by,
       username,
       domain_id,
       password,
       enabled,
       update_version)
    values
      (subjectId,
       sysdate,
       null,
       null,
       null,
       userName,
       61,
       '3b1ebd28a439664eee0efcbd7b88d862',
       1,
       1);
    insert into rbac_subject_role_ref
      (subject_id, role_id)
    values
      (subjectId, 3);

  end loop;
  commit;
    msg := 'SUCCESS';

Exception
  When others then
    msg := dbms_utility.format_error_backtrace() || SUBSTR(SQLERRM, 1, 200);
    rollback;
end copy_channel_info;






/

