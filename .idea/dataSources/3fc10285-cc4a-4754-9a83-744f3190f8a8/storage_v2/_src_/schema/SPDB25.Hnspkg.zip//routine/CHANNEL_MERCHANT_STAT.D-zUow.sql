create procedure channel_merchant_stat(merchantCodeLen in number,
                                                  checkMode       in varchar2,
                                                  retCode         out Integer,
                                                  retMsg          out varchar2,
                                                  pay_date        out varchar2)
  Authid CURRENT_USER is
  startDate varchar2(32);
  endDate   varchar2(32);
begin
  retCode := 0;
  retMsg  := 'success';
  --订单对比统计
  retMsg := func_order_compare(merchantCodeLen, startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 1;
    return;
  end if;
  pay_date := startDate;
  --退款单对比统计
  retMsg := func_refund_compare(merchantCodeLen, startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 2;
    return;
  end if;
  --对账结果统计
  retMsg := func_compare_result_stat(startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 3;
    return;
  end if;
  --清理清分数据表
  retMsg := func_init_bill_cleaning(startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 4;
    return;
  end if;

  --生成日结统计
  retMsg := func_pay_day_bill_stat(checkMode, startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 5;
    return;
  end if;
  --插入历史表
  retMsg := func_save_pay_bill(startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 6;
    return;
  end if;

  --计算渠道的分润
  retMsg := func_channel_merchant_benefit(startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 7;
    return;
  end if;

  --对于私有云的日结单，将启动清分程序进行清分表
  retMsg := func_merchant_clearing(startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 8;
    return;
  end if;

  --计算渠道清分
  retMsg := func_channel_clearing(startDate, endDate);
  if (retMsg <> 'success') then
    retCode := 9;
    return;
  end if;

  commit;
Exception
  When others then
    retCode := SQLCODE;
    retMsg  := SUBSTR(SQLERRM, 1, 200);
    rollback;
end channel_merchant_stat;






/

