create function func_channel_merchant_benefit(startDate in varchar2,
                                                         endDate   in varchar2)
  RETURN varchar2 is
  sql0              varchar2(1024);
  msg               varchar2(1024);
  rateType          varchar2(6);
  payRate           number(20, 6);
  billRate          number(20, 6); --商户费率
  costRate          number(20, 6);
  channelRate       number(20, 6); --渠道的浮动费率
  channelExeRate    number(20, 6); --渠道的执行费率
  p_channelId       varchar2(32);
  channelId         varchar2(32);
  parentInviteCode  varchar(32);
  channelBenefitFee number(20, 6);
  benefitFee        number(20, 6);
  actualBenefitFee  number(20, 2);
  cftRemitFee       number(20, 2);
  mchRemitFee       number(20, 2);
  aMchRemitFee      number(20, 2);
  total_count       number(20); --交易笔数
  third_fee         number(20, 2); --财付通手续费
  cleanDate varchar2(128);
  cleaning_date varchar2(128);
  CURSOR cur_01 IS
  --查询出该渠道对应商户的所有支付类型
    select pay_mode,
           pay_name,
           pay_date,
           merchant_code,
           total_count,
           total_fee,
           refund_count,
           refund_fee,
           total_netfee,
           rate
      from PF_PAY_DAY_BILL
     order by merchant_code;
  CURSOR cur_02 IS
  --更新威富通的实际打款金额，否则这里会导致不一至
    select distinct to_char(pay_date, 'yyyy-MM-dd') as pay_date,
                    pay_mode,
                    merchant_code
      from pf_channel_merchant_stat
     where to_char(pay_date, 'yyyy-MM-dd') between startDate and endDate;

  CURSOR cur_03 IS
  --按渠道和支付方式进行分类进行统计
    select to_char(pay_date, 'yyyy-MM-dd') as pay_date,
           channel_id,
           pay_mode,
           pay_name,
           sum(total_count + refund_count) as total_count,
           round(sum(total_netfee), 2) as total_netfee,
           round(sum(actual_benefit_fee), 2) as total_benefit_fee,
           round(sum(a_actual_benefit_fee), 2) as a_total_benefit_fee,
           to_char(cleaning_date, 'yyyy-MM-dd') as cleaning_date
      from pf_channel_merchant_stat
     where to_char(pay_date, 'yyyy-MM-dd') between startDate and endDate
     group by channel_id,
              pay_mode,
              pay_name,
              to_char(pay_date, 'yyyy-MM-dd'),
              to_char(cleaning_date, 'yyyy-MM-dd');

begin
  msg := 'success';

  for rec1 in cur_01 loop

    --查询得到商户的成本费率
    begin
      sql0 := 'select cost_rate,pay_rate from pf_merchant_pay_info
            where merchant_id=(select merchant_id from pf_merchant_info
            where merchant_code=''' || rec1.merchant_code ||
              ''') and pay_mode=''' || rec1.pay_mode || '''';
      execute immediate sql0
        into costRate, billRate;
      if (costRate is null) then
        costRate := 0.0;
      end if;
      if (billRate is null) then
        billRate := 0.0;
      end if;
    exception
      when NO_DATA_FOUND then
        --没有查询到商户的费率，直接返回
        msg := 'can''t find merchant pay info according to merchant code and pay mode,merchant code is:' ||
               rec1.merchant_code || ' and pay_mode is:' || rec1.pay_mode;
        rollback;
        return msg;
    end;

    --得到商户对应渠道的渠道号和父级邀请码
    begin
      sql0 := 'select channel_id,parent_invite_code from pf_channel_info
              where channel_id=(select channel_id from pf_merchant_info where merchant_code=''' ||
              rec1.merchant_code || ''')';
      execute immediate sql0
        into channelId, parentInviteCode;
    exception
      when NO_DATA_FOUND then
        msg := 'can''t find channel info according to merchant code,merchant code is:' ||
               rec1.merchant_code;
        rollback;
        return msg;
    end;
    --得到渠道的费率
    begin
      sql0 := 'select rate_type,rate from pf_channel_rate_info
              where channel_id=''' || channelId ||
              ''' and pay_mode=''' || rec1.pay_mode || '''';
      execute immediate sql0
        into rateType, payRate;
    exception
      when NO_DATA_FOUND then
        --没有查询到则设置为默认费率
        rateType := 'RAT001'; --默认固定费率
        payRate  := 0.0; --默认为0
    end;

    --开始计算后保存
    if (parentInviteCode <> '0') then
      if (rateType = 'RAT001') then
        --固定费率
        channelRate    := billRate - payRate;
        channelExeRate := payRate;
      else
        channelRate    := payRate; --浮动费率
        channelExeRate := billRate - payRate;
      end if;
    else
      --为顶级渠道时直接就是商户费率-成本费率
      channelRate    := billRate - costRate;
      channelExeRate := channelRate;
    end if;
    benefitFee       := channelExeRate * rec1.total_netfee / 1000;
    actualBenefitFee := round(benefitFee, 2);
    msg := func_c_cleaning_date_stat(to_date(startDate, 'yyyy-MM-dd'),
                                   1,
                                   'SPDB_GUANGZHOU',
                                   cleanDate);
    if (msg <> 'success') then
      return msg;
    end if;
    sql0 := 'insert into pf_channel_merchant_stat(id,pay_date,pay_mode,pay_name,rate,channel_id,channel_flag,merchant_code,
               total_count,total_fee,refund_count,refund_fee,total_netfee,total_benefit_fee,actual_benefit_fee,a_actual_benefit_fee,UPDATE_VERSION,cleaning_date) values( pf_channel_merchant_stat_SEQ.Nextval,' || '''' ||
            rec1.pay_date || '''' || ',' || '''' || rec1.pay_mode || '''' || ',' || '''' ||
            rec1.pay_name || '''' || ',' || channelExeRate || ',' || '''' ||
            channelId || '''' || ',' || '''' || channelId || '''' || ',' || '''' ||
            rec1.merchant_code || '''' || ',' || rec1.total_count || ',' ||
            rec1.total_fee || ',' || rec1.refund_count || ',' ||
            rec1.refund_fee || ',' || rec1.total_netfee || ',' ||
            benefitFee || ',' || actualBenefitFee || ',' ||
            actualBenefitFee || ',0,to_date(''' || cleanDate || ''',''yyyy-MM-dd''))';
    execute immediate sql0;
    if (parentInviteCode = '0') then
      continue; --此商户就为顶级渠道的商户，不进入循环继续下一条数据统计
    end if;
    select parent_invite_code
      into parentInviteCode
      from pf_channel_info
     where channel_id = channelId;

    while 1 = 1 loop
      --查询得到父渠道的ID
      select channel_id, parent_invite_code
        into p_channelId, parentInviteCode
        from pf_channel_info
       where invite_code = parentInviteCode;

      begin
        sql0 := 'select rate_type,rate from PF_CHANNEL_RATE_INFO where channel_id = ''' ||
                p_channelId || ''' and pay_mode=''' || rec1.pay_mode || '''';
        execute immediate sql0
          into rateType, payRate;
      exception
        when NO_DATA_FOUND then
          --没有查询到则设置为默认费率
          rateType := 'RAT001'; --默认固定费率
          payRate  := 0.0; --默认为0
      end;
      --开始计算后保存
      if (parentInviteCode <> '0') then
        if (rateType = 'RAT001') then
          --固定费率
          channelRate    := channelRate - payRate;
          channelExeRate := payRate;
        else
          channelExeRate := channelRate - payRate;
          channelRate    := payRate; --浮动费率
        end if;
      else
        --为0级渠道时直接是渠道的执行费率-成本费率
        channelRate    := channelRate - costRate;
        channelExeRate := channelRate;
      end if;
      --开始计算后保存
      benefitFee       := channelExeRate * rec1.total_netfee / 1000;
      actualBenefitFee := round(benefitFee, 2);
      msg := func_c_cleaning_date_stat(to_date(startDate, 'yyyy-MM-dd'),
                                   1,
                                   'SPDB_GUANGZHOU',
                                   cleanDate);
      if (msg <> 'success') then
        return msg;
      end if;
      sql0 := 'insert into pf_channel_merchant_stat(id,pay_date,pay_mode,pay_name,rate,channel_id,channel_flag,merchant_code,
               total_count,total_fee,refund_count,refund_fee,total_netfee,total_benefit_fee,actual_benefit_fee,a_actual_benefit_fee,UPDATE_VERSION,cleaning_date) values( pf_channel_merchant_stat_SEQ.Nextval,' || '''' ||
              rec1.pay_date || '''' || ',' || '''' || rec1.pay_mode || '''' || ',' || '''' ||
              rec1.pay_name || '''' || ',' || channelExeRate || ',' || '''' ||
              p_channelId || '''' || ',' || '''' || channelId || '''' || ',' || '''' ||
              rec1.merchant_code || '''' || ',' || rec1.total_count || ',' ||
              rec1.total_fee || ',' || rec1.refund_count || ',' ||
              rec1.refund_fee || ',' || rec1.total_netfee || ',' ||
              benefitFee || ',' || actualBenefitFee || ',' ||
              actualBenefitFee || ',0,to_date(''' || cleanDate || ''',''yyyy-MM-dd''))';
      execute immediate sql0;
      if (parentInviteCode = '0') then
        exit; --已经到顶级渠道，退出循环
      end if;
      select parent_invite_code
        into parentInviteCode
        from pf_channel_info
       where channel_id = p_channelId;
    end loop;
  end loop;

  for rec02 in cur_02 loop
    begin
      --将各种误差放入到银行平台下面
      select sum(nvl(a_actual_benefit_fee,0))
        into channelBenefitFee
        from pf_channel_merchant_stat
       where channel_id <> (select channel_id
                              from pf_channel_info
                             where parent_invite_code = '0')
         and to_char(pay_date, 'yyyy-MM-dd') = rec02.pay_date
         and pay_mode = rec02.pay_mode
         and merchant_code = rec02.merchant_code;

      --计算得到财付通的打款金额
      select nvl(total_netfee,0) - nvl(third_fee, 0),
             nvl(merchant_remit_fee, 0),
             round(a_merchant_remit_fee, 2)
        into cftRemitFee, mchRemitFee, aMchRemitFee
        from pf_pay_day_bill_history
       where merchant_code = rec02.merchant_code
         and pay_mode = rec02.pay_mode
         and to_char(pay_date, 'yyyy-MM-dd') = rec02.pay_date;
      --误差全部归到银行平台的明细数据中
      update pf_channel_merchant_stat
         set actual_benefit_fee   = cftRemitFee - channelBenefitFee -
                                    mchRemitFee,
             a_actual_benefit_fee = cftRemitFee - channelBenefitFee -
                                    aMchRemitFee
       where channel_id = (select channel_id
                             from pf_channel_info
                            where parent_invite_code = '0')
         and to_char(pay_date, 'yyyy-MM-dd') = rec02.pay_date
         and pay_mode = rec02.pay_mode
         and merchant_code = rec02.merchant_code;
    exception
      when NO_DATA_FOUND then
        --没有查询到威富通的渠道则退出循环
        exit;
    end;
  end loop;

  --这里进行汇总统计
  for rec03 in cur_03 loop
    sql0 := 'insert into pf_channel_benefit_stat(id,pay_date,pay_mode,pay_name,channel_id,total_netfee,
          total_benefit_fee,a_total_benefit_fee,UPDATE_VERSION,total_count,cleaning_date)values(pf_channel_benefit_stat_SEQ.nextval,' ||
            'TO_TIMESTAMP(''' || rec03.pay_date || ' 00:00:00.000000000''' ||
            ', ''YYYY-MM-DD HH24:MI:SS.FF'')' || ',''' || rec03.pay_mode ||
            ''',''' || rec03.pay_name || ''',''' || rec03.channel_id ||
            ''',' || rec03.total_netfee || ',' || rec03.total_benefit_fee || ',' ||
            rec03.a_total_benefit_fee || ',0,' || rec03.total_count ||
            ',to_date(''' || rec03.cleaning_date || ''',''yyyy-MM-dd''))';
    execute immediate sql0;
  end loop;
  return msg;
Exception
  When others then
    msg := SUBSTR(SQLERRM, 1, 200);
    rollback;
    return msg;
end func_channel_merchant_benefit;






/

