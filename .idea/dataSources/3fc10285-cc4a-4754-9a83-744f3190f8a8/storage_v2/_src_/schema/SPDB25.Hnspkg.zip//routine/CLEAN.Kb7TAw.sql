create procedure clean Authid CURRENT_USER is
      sql0 varchar2(512);
      CURSOR cur_01 IS
          select * from  user_objects where object_type = 'TABLE';
      CURSOR cur_02 IS
          select * from  user_objects where object_type = 'FUNCTION';
      CURSOR cur_03 IS
          select * from user_objects where object_type = 'PROCEDURE';
      CURSOR cur_04 IS
          select * from user_objects where object_type = 'SEQUENCE';
begin
      for rec01 in cur_01 loop
        sql0 := 'drop table '||rec01.object_name;
        execute immediate sql0;
      end loop;
      for rec02 in cur_02 loop
        sql0 := 'drop function '||rec02.object_name;
        execute immediate sql0;
      end loop;
      for rec03 in cur_03 loop
        if(rec03.object_name = 'CLEAN')then
           continue;
        end if;
        sql0 := 'drop procedure '||rec03.object_name;
        execute immediate sql0;
      end loop;
      for rec04 in cur_04 loop
        sql0 := 'drop sequence '||rec04.object_name;
        execute immediate sql0;
      end loop;
end clean;






/

