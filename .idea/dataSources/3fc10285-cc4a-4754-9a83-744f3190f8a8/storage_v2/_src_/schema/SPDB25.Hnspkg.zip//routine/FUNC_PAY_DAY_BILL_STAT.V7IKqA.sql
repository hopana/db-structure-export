create FUNCTION FUNC_PAY_DAY_BILL_STAT(CHECKMODE IN VARCHAR2,
                                                  STARTDATE IN VARCHAR2,
                                                  ENDDATE   IN VARCHAR2)
  RETURN VARCHAR2 IS
  MSG            VARCHAR(1024);
  SQL0           VARCHAR(2048);
  MERCHANTCODE   VARCHAR(32);
  PAYTYPE        VARCHAR(32);
  PAYDATE        VARCHAR(32);
  REFUNDCOUNT    NUMBER(11);
  REFUNDFEE      NUMBER(11, 2);
  MERCHANTFEE    NUMBER(11, 2);
  THIRDFEE       NUMBER(11, 2);
  iCount            number(11);
  CURSOR REFUND_CUR IS
    SELECT W_MERCHANT_CODE,
           W_PAY_TYPE,
           TO_CHAR(W_ORDER_REFUND_TIME, 'yyyy-MM-dd'),
           COUNT(1),
           SUM(NVL(C_REFUND_FEE, 0)),
           SUM(NVL(C_REFUND_BENEFIT_FEE, 0)),
           SUM(NVL(MERCHANT_FEE, 0))
      FROM PF_MERCHANT_REFUND_INFO
     WHERE W_MERCHANT_CODE NOT IN
           (SELECT DISTINCT W_MERCHANT_CODE
              FROM PF_MERCHANT_ORDER_INFO
             WHERE COMPARE_RESULT <> 'RET000'
               AND W_MERCHANT_CODE IS NOT NULL)
       AND W_MERCHANT_CODE NOT IN
           (SELECT DISTINCT C_MERCHANT_CODE
              FROM PF_MERCHANT_ORDER_INFO
             WHERE COMPARE_RESULT <> 'RET000'
               AND C_MERCHANT_CODE IS NOT NULL)
       AND W_MERCHANT_CODE NOT IN
           (SELECT DISTINCT C_MERCHANT_CODE
              FROM PF_MERCHANT_REFUND_INFO
             WHERE COMPARE_RESULT <> 'RET000'
               AND C_MERCHANT_CODE IS NOT NULL)
       AND W_MERCHANT_CODE NOT IN
           (SELECT DISTINCT W_MERCHANT_CODE
              FROM PF_MERCHANT_REFUND_INFO
             WHERE COMPARE_RESULT <> 'RET000'
               AND W_MERCHANT_CODE IS NOT NULL)
       AND TO_CHAR(C_REFUND_TIME, 'yyyy-MM-dd') BETWEEN STARTDATE AND
           ENDDATE
     GROUP BY W_MERCHANT_CODE,
              W_PAY_TYPE,
              TO_CHAR(W_ORDER_REFUND_TIME, 'yyyy-MM-dd');

  CURSOR REFUND_CUR1 IS
    SELECT C_MERCHANT_CODE,
           C_PAY_TYPE,
           TO_CHAR(C_REFUND_TIME, 'yyyy-MM-dd'),
           COUNT(1),
           SUM(NVL(C_REFUND_FEE, 0)),
           SUM(NVL(C_REFUND_BENEFIT_FEE, 0)),
           SUM(NVL(MERCHANT_FEE, 0))
      FROM PF_MERCHANT_REFUND_INFO
     WHERE COMPARE_RESULT <> 'RET001'
       AND TO_CHAR(C_REFUND_TIME, 'yyyy-MM-dd') BETWEEN STARTDATE AND
           ENDDATE
     GROUP BY C_MERCHANT_CODE,
              C_PAY_TYPE,
              TO_CHAR(C_REFUND_TIME, 'yyyy-MM-dd');
BEGIN
  MSG := 'success';
  --删除日结单表的数据
  DELETE FROM PF_PAY_DAY_BILL;
  IF (CHECKMODE = 'CHK001') THEN
    --根据账对平的商户和支付方式进行汇总
    SQL0 := 'insert into pf_pay_day_bill(pay_date,merchant_code,pay_mode,pay_name,total_count,
          total_fee,cost_rate,third_fee,rate,merchant_fee)select to_timestamp(to_char(w_order_trade_time,''yyyy-MM-dd''),''yyyy-MM-dd''),
          w_merchant_code,w_pay_type,w_pay_name,count(1)as total_count,
          sum(w_total_fee)/100 as total_fee,c_cost_rate*10,
          sum(c_total_benefit_fee) as third_fee,pay_rate,sum(merchant_fee)
          from PF_MERCHANT_ORDER_INFO where
          w_merchant_code not in(select distinct w_merchant_code from PF_MERCHANT_ORDER_INFO where compare_result<>''RET000'' and w_merchant_code is not null)
          and w_merchant_code not in(select distinct c_merchant_code from PF_MERCHANT_ORDER_INFO where compare_result<>''RET000'' and c_merchant_code is not null) and
          to_char(w_order_trade_time,''yyyy-MM-dd'') between ''' ||
            STARTDATE || ''' and ''' || ENDDATE || '''
          group by w_pay_type,w_merchant_code,pay_rate,
          w_pay_name,c_cost_rate,to_char(w_order_trade_time,''yyyy-MM-dd'')';
    EXECUTE IMMEDIATE SQL0;
  ELSIF (CHECKMODE = 'CHK002') THEN
    --第三方对账单为准生成日结
    SQL0 := ' insert into pf_pay_day_bill(pay_date,merchant_code,pay_mode,pay_name,total_count,
          total_fee,cost_rate,third_fee,rate,merchant_fee)
          select to_timestamp(to_char(c_trade_time,''yyyy-MM-dd''),''yyyy-MM-dd''),
          c_merchant_code,c_pay_type,b.pay_name,count(1)as total_count,
          sum(c_total_fee) as total_fee,c_cost_rate*10,
          sum(c_total_benefit_fee) as third_fee,pay_rate,sum(merchant_fee)
          from PF_MERCHANT_ORDER_INFO a left join pf_pay_center b on a.c_pay_type=b.pay_mode where compare_result<>''RET001'' and
          to_char(c_trade_time,''yyyy-MM-dd'') between ''' ||
            STARTDATE || ''' and ''' || ENDDATE || '''
          group by c_pay_type,b.pay_name,c_merchant_code,pay_rate,
          c_cost_rate,to_char(c_trade_time,''yyyy-MM-dd'')';
    EXECUTE IMMEDIATE SQL0;
  ELSIF (CHECKMODE = 'CHK003') THEN
    --公有云对账，以第三方为准生成日结
    SQL0 := ' insert into pf_pay_day_bill(pay_date,merchant_code,pay_mode,pay_name,total_count,
          total_fee,cost_rate,third_fee,rate,merchant_fee)
          select to_timestamp(to_char(c_trade_time,''yyyy-MM-dd''),''yyyy-MM-dd''),
          c_merchant_code,c_pay_type,b.pay_name,count(1)as total_count,
          sum(c_total_fee) as total_fee,c_cost_rate*10,
          sum(c_total_benefit_fee) as third_fee,pay_rate,sum(merchant_fee)
          from PF_MERCHANT_ORDER_INFO a left join pf_pay_center b on a.c_pay_type=b.pay_mode where compare_result<>''RET001'' and
          to_char(c_trade_time,''yyyy-MM-dd'') between ''' ||
            STARTDATE || ''' and ''' || ENDDATE || '''
          group by c_pay_type,b.pay_name,c_merchant_code,pay_rate,
          c_cost_rate,to_char(c_trade_time,''yyyy-MM-dd'')';
  ELSE
    MSG := '清分模式没有匹配成功';
    ROLLBACK;
    RETURN MSG;
  END IF;
  --初始化日结中的对账数据
  SQL0 := 'update pf_pay_day_bill set refund_count=0,
      refund_fee=0,total_netfee=total_fee,
      merchant_fee=merchant_fee
      where to_char(pay_date,''yyyy-MM-dd'') between ''' ||
          STARTDATE || ''' and ''' || ENDDATE || '''';
  EXECUTE IMMEDIATE SQL0;
  SQL0 := 'update pf_pay_day_bill set merchant_remit_fee=total_netfee-merchant_fee where to_char(pay_date,''yyyy-MM-dd'') between ''' ||
          STARTDATE || ''' and ''' || ENDDATE || '''';
  EXECUTE IMMEDIATE SQL0;
  --根据对账平的商户和支付方式进行退款汇总统计
  BEGIN
    IF (CHECKMODE = 'CHK001') THEN
      IF (REFUND_CUR%ISOPEN = FALSE) THEN
        OPEN REFUND_CUR;
      END IF;

      LOOP
        FETCH REFUND_CUR
          INTO MERCHANTCODE,
               PAYTYPE,
               PAYDATE,
               REFUNDCOUNT,
               REFUNDFEE,
               THIRDFEE,
               MERCHANTFEE;
        EXIT WHEN REFUND_CUR%NOTFOUND;
        select count(1)
          into iCount
          from pf_pay_day_bill
         where merchant_code = merchantCode
           and pay_mode = payType
           and to_char(pay_date, 'yyyy-MM-dd') = payDate;
        if (iCount = 0) then
          msg := 'Can''t find pay day bill refund according to merchant_code:' ||
                 merchantCode || ' and pay_mode:' || payType ||
                 ' and pay date:' || payDate;
          rollback;
          return msg;
        end if;
        SQL0 := 'update pf_pay_day_bill set refund_count=' || REFUNDCOUNT || ',' ||
                'refund_fee=' || REFUNDFEE || ',' ||
                'total_netfee=total_fee-' || REFUNDFEE ||
                ',third_fee=third_fee+' || THIRDFEE ||
                ',merchant_fee=merchant_fee-' || MERCHANTFEE ||
                ' where merchant_code=''' || MERCHANTCODE ||
                ''' and pay_mode=''' || PAYTYPE ||
                ''' and to_char(pay_date,''yyyy-MM-dd'')=''' || PAYDATE || '''';
        EXECUTE IMMEDIATE SQL0;
        SQL0 := 'update pf_pay_day_bill set merchant_remit_fee=total_netfee-merchant_fee where to_char(pay_date,''yyyy-MM-dd'') between ''' ||
                STARTDATE || ''' and ''' || ENDDATE || '''';
        EXECUTE IMMEDIATE SQL0;
      END LOOP;
      CLOSE REFUND_CUR;

    ELSIF (CHECKMODE = 'CHK002') THEN

      IF (REFUND_CUR1%ISOPEN = FALSE) THEN
        OPEN REFUND_CUR1;
      END IF;

      LOOP
        FETCH REFUND_CUR1
          INTO MERCHANTCODE,
               PAYTYPE,
               PAYDATE,
               REFUNDCOUNT,
               REFUNDFEE,
               THIRDFEE,
               MERCHANTFEE;
        EXIT WHEN REFUND_CUR1%NOTFOUND;
        select count(1)
          into iCount
          from pf_pay_day_bill
         where merchant_code = merchantCode
           and pay_mode = payType
           and to_char(pay_date, 'yyyy-MM-dd') = payDate;

        if (iCount = 0) then
          msg := 'Can''t find pay day bill according to merchant_code:' ||
                 merchantCode || ' and pay_mode:' || payType ||
                 ' and pay date:' || payDate;
          rollback;
          return msg;
        end if;

        SQL0 := 'update pf_pay_day_bill set refund_count=' || REFUNDCOUNT || ',' ||
                'refund_fee=' || REFUNDFEE || ',' ||
                'total_netfee=total_fee-' || REFUNDFEE ||
                ',third_fee=third_fee+' || THIRDFEE ||
                ',merchant_fee=merchant_fee-' || MERCHANTFEE ||
                ' where merchant_code=''' || MERCHANTCODE ||
                ''' and pay_mode=''' || PAYTYPE ||
                ''' and to_char(pay_date,''yyyy-MM-dd'')=''' || PAYDATE || '''';
        EXECUTE IMMEDIATE SQL0;
        SQL0 := 'update pf_pay_day_bill set merchant_remit_fee=total_netfee-merchant_fee where to_char(pay_date,''yyyy-MM-dd'') between ''' ||
                STARTDATE || ''' and ''' || ENDDATE || '''';
        EXECUTE IMMEDIATE SQL0;
      END LOOP;
      CLOSE REFUND_CUR1;
    ELSE

      NULL;
    END IF;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL; --没有找到什么也不做
  END;
  RETURN MSG;
EXCEPTION
  WHEN OTHERS THEN
    MSG := SUBSTR(SQLERRM, 1, 200);
    ROLLBACK;
    RETURN MSG;
END FUNC_PAY_DAY_BILL_STAT;






/

