create function func_tran_str(str in varchar2) return varchar2
is
msg varchar2(32);
begin
  msg := '''' || str || '''';
  return msg;
end func_tran_str;






/

