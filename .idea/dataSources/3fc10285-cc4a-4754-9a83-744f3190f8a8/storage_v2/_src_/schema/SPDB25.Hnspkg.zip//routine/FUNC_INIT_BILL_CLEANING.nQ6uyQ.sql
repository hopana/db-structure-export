create function func_init_bill_cleaning(startDate in varchar2,endDate in varchar2) RETURN varchar2 is
    msg varchar(1024);
begin
      msg:='success';
      --对于多次导入，这里根据时间将删除掉历史记录
      delete from PF_PAY_DAY_BILL_HISTORY where to_char(pay_date,'yyyy-MM-dd') between startDate and endDate;
      delete from pf_channel_merchant_stat where to_char(pay_date,'yyyy-MM-dd') between startDate and endDate;
      delete from pf_channel_benefit_stat where to_char(pay_date,'yyyy-MM-dd') between startDate and endDate;
      delete from pf_merchant_cleaning_info where flag not in('y','Y') and is_channel = 'CLR002' and (to_char(pay_date,'yyyy-MM-dd') between startDate and endDate);
        return msg;
         Exception
          When others then
            msg := SUBSTR(SQLERRM, 1, 200);
            rollback;
            return msg;
end func_init_bill_cleaning;






/

