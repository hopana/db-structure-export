create function func_tran_date_to_char(dateStr in out timestamp) return
  varchar2
  is
  a varchar2(32);
begin
  --a := cast(dateStr as varchar2);
  --select cast(dateStr as date) into a from dual;
  a := '''' || to_char(dateStr,'yyyy-MM-dd hh24:mi:ss') || '''';
  return a;
end func_tran_date_to_char;






/

