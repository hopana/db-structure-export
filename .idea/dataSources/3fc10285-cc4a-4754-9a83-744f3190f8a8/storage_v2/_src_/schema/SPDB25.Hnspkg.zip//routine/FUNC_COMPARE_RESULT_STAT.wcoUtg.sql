create function func_compare_result_stat(startDate in varchar2,
                                                    endDate   in varchar2)
  return varchar2 is
  msg                 varchar2(1024);
  sql01               varchar2(2048);
  v_total_count       number(20);
  v_total_fee         number(20, 2);
  v_total_benefit_fee number(20, 2);
  v_total_else_fee    number(20, 2);
  v_compare_result    varchar2(32);
  v_c_pay_type        varchar(128);
  v_is_bank           number(1);
  v_c_trade_time      varchar2(128);
  i_count             number(20);
  v_account_type      varchar2(64);
  iCount              number(11);
  pRow                number(11);
  cursor cur_refund_count is
    select b.account_type as v_account_type,
           b.is_bank as v_is_bank,
           w.c_pay_type as v_c_pay_type,
           w.compare_result as v_compare_result,
           count(1) as v_total_count,
           sum(w.c_refund_fee) as v_total_fee,
           sum(w.c_refund_benefit_fee) as v_total_benefit_fee,
           (sum(w.c_refund_fee) + sum(w.c_refund_benefit_fee)) as v_total_else_fee,
           to_char(w.c_refund_time, 'yyyy-MM-dd') as v_c_trade_time
      from pf_merchant_refund_info w
      left join pf_merchant_info a
        on w.c_merchant_code = a.merchant_code
      left join pf_merchant_pay_info b
        on a.merchant_id = b.merchant_id and w.c_pay_type = b.pay_mode
     where to_char(w.c_refund_time, 'yyyy-MM-dd') between startDate and
           endDate
       and w.compare_result in ('RET002', 'RET000')
     group by w.compare_result,
              w.c_pay_type,
              b.is_bank,
              b.account_type,
              to_char(w.c_refund_time, 'yyyy-MM-dd');
begin
  msg := 'success';
  -----------------统计对账结果--------------
  select count(1)
    into iCount
    from pf_bill_compare_stat
   where to_char(bill_time, 'yyyy-MM-dd') between startDate and endDate
     and trnser is not null;
  if (iCount = 0) then
    delete from pf_bill_compare_stat
     where to_char(bill_time, 'yyyy-MM-dd') between startDate and endDate;
    select count(1)
      into i_count
      from pf_merchant_order_info w
     where to_char(w.c_trade_time, 'yyyy-MM-dd') between startDate and
           endDate
       and w.compare_result in ('RET002', 'RET000');
    if (i_count > 0) then
      --统计财付通多余和对平的数据
      --成功订单
      sql01 := 'insert into pf_bill_compare_stat(account_type,is_bank,pay_type,compare_result,total_count,total_fee,total_benefit_fee,
   total_else_fee,bill_time,add_time)select b.account_type,b.is_bank,w.c_pay_type,
   w.compare_result,
   count(1) as totalCount,
           sum(w.c_total_fee) as totalFee,
           sum(w.c_total_benefit_fee) as totalBenefitFee,
           (sum(w.c_total_fee) - sum(w.c_total_benefit_fee)) as totalElseFee,
           to_date(to_char(c_trade_time,''yyyy-MM-dd''),''yyyy-MM-dd''),sysdate
      from pf_merchant_order_info w
      left join pf_merchant_info a
        on w.c_merchant_code = a.merchant_code
      left join pf_merchant_pay_info b
        on a.merchant_id = b.merchant_id and w.c_pay_type = b.pay_mode
     where to_char(w.c_trade_time, ''yyyy-MM-dd'') between ''' ||
               startDate || ''' and ''' || endDate || '''' ||
               ' and w.compare_result in (''RET002'', ''RET000'')
     group by w.compare_result,
              w.c_pay_type,
              b.is_bank,b.account_type,
              to_date(to_char(c_trade_time,''yyyy-MM-dd''),''yyyy-MM-dd'')';
      execute immediate sql01;
    end if;
    select count(1)
      into i_count
      from pf_merchant_order_info w
     where to_char(w.w_order_trade_time, 'yyyy-MM-dd') between startDate and
           endDate
       and w.compare_result = 'RET001';
    if (i_count > 0) then
      --做判断分开
      --统计威富通多余的数据
      sql01 := 'insert into pf_bill_compare_stat(account_type,is_bank,pay_type,compare_result,total_count,total_fee,total_benefit_fee,
   total_else_fee,bill_time,add_time)select b.account_type,b.is_bank,w.w_pay_type,
   w.compare_result,
   count(1) as totalCount,
           sum(w.w_total_fee) as totalFee,
           0,
           sum(w.w_total_fee) as totalElseFee,
           to_date(to_char(w_order_trade_time,''yyyy-MM-dd''),''yyyy-MM-dd''),sysdate
      from pf_merchant_order_info w
      left join pf_merchant_info a
        on w.w_merchant_code = a.merchant_code
      left join pf_merchant_pay_info b
        on a.merchant_id = b.merchant_id and w.w_pay_type = b.pay_mode
     where to_char(w.w_order_trade_time, ''yyyy-MM-dd'') between ''' ||
               startDate || ''' and ''' || endDate || '''' ||
               ' and w.compare_result = ''RET001''
     group by w.compare_result,
              w.w_pay_type,
              b.is_bank,b.account_type,
              to_date(to_char(w_order_trade_time,''yyyy-MM-dd''),''yyyy-MM-dd'')';
      execute immediate sql01;
    end if;
    begin
      --退款订单
      if (cur_refund_count%isopen = false) then
        open cur_refund_count;
      end if;
      loop
        fetch cur_refund_count
          into v_account_type,
               v_is_bank,
               v_c_pay_type,
               v_compare_result,
               v_total_count,
               v_total_fee,
               v_total_benefit_fee,
               v_total_else_fee,
               v_c_trade_time;
        exit when cur_refund_count%notfound;
        sql01 := 'update pf_bill_compare_stat set total_fee = total_fee -' ||
                 v_total_fee || ',total_count = total_count + ' ||
                 v_total_count || ',
    total_else_fee = total_else_fee - ' || v_total_else_fee ||
                 ',total_benefit_fee = total_benefit_fee +' ||
                 v_total_benefit_fee || '
     where is_bank = ' || v_is_bank || ' and pay_type = ''' ||
                 v_c_pay_type || ''' and compare_result = ''' ||
                 v_compare_result ||
                 ''' and to_char(bill_time,''yyyy-MM-dd'') = ''' ||
                 startDate || '''' || ' and account_type = ''' ||
                 v_account_type || '''';
        execute immediate sql01;
        pRow := SQL%ROWCOUNT;
      end loop;
      close cur_refund_count;
      /*exception
      when NO_DATA_FOUND then
        msg := SUBSTR(SQLERRM, 1, 800);
        rollback;
        return msg;*/
    end;
  end if;

  return msg;
Exception
  When others then
    msg := SUBSTR(SQLERRM, 1, 800);
    rollback;
    return msg;
end func_compare_result_stat;






/

