create procedure check_channel_pay_rate(channelId in varchar2,payMode in varchar2,
payRate in number,rateType in varchar2,retCode out Integer,retMsg out varchar2 ) Authid CURRENT_USER is
      iChannelId varchar2(32);--渠道循环变量
      iMerchantId number(11);
      inviteCode varchar(32);
       CURSOR cur_01 IS
          SELECT channel_id，parent_invite_code，invite_code FROM pf_channel_info start with invite_code=InviteCode connect by prior invite_code = parent_invite_code;
       CURSOR cur_02 IS
          select merchant_id  from pf_merchant_info where channel_id=iChannelId;
       CURSOR cur_03 IS
          select pay_rate  from pf_merchant_pay_info where merchant_id=iMerchantId and pay_mode=payMode;
begin
      retCode:=0;
      retMsg:='ok';
      select invite_code into InviteCode from pf_channel_info where channel_id = channelId;
      for rec1 in cur_01 loop
        iChannelId := rec1.channel_id;
        for rec2 in cur_02 loop
          iMerchantId := rec2.merchant_id;
          for rec3 in cur_03 loop
            --这里判断各级渠道是否分配合理
             retMsg := fun_check_channel_pay_rate(iMerchantId,iChannelId,rec3.pay_rate,channelId,payMode,rateType,payRate);
             if(retMsg<>'ok')then
                retCode := -1;
                return;
             end if;
          end loop;
        end loop;
      end loop;
end check_channel_pay_rate;






/

