create FUNCTION "FUN_GET_UNIQUE_ID" (pCatName in varchar2, pItemName in varchar2) return number is
  Result number;
  PRAGMA AUTONOMOUS_TRANSACTION;
vCatName PF_UNIQUE_KEYS.cat_name%type;
vItemName PF_UNIQUE_KEYS.item_name%type;
begin
--  select 1 into UniqueID from dual;
  vCatName := Upper(pCatName);
  vItemName := Upper(pItemName);

  update PF_UNIQUE_KEYS
  set last_key = last_key + 1,fresh_date=sysdate
  where cat_name=vCatName and item_name=vItemName;

  if SQL%NotFound then
    insert into PF_UNIQUE_KEYS(cat_name,item_name,last_key,fresh_date)
    values(vCatName,vItemName,1,sysdate);
  end if;

  select last_key into Result
  from PF_UNIQUE_KEYS
  where cat_name=vCatName and item_name=vItemName;

  commit;
  return(Result);
exception
  when others then
    rollback;
    Raise_application_error(-20000, '????(FUN_GET_UNIQUE_ID)????');
end Fun_Get_Unique_Id;






/

