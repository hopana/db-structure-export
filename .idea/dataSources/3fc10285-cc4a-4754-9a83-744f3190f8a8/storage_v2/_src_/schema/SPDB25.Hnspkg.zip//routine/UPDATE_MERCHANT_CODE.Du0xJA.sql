create procedure update_merchant_code(retCode out Integer,retMsg out varchar2) Authid CURRENT_USER is
      sql0 varchar2(512);
      merchantId number(11);
      CURSOR cur_01 IS
          select private_merchant_id,public_merchant_id,merchant_code from  PF_MERCHANT_RELATION_INFO;
      CURSOR cur_02 IS
          select pay_center,pay_mode,pay_name from  PF_PAY_CENTER_MODE_INFO where private_merchant_id=merchantId;
begin
      retCode := 0;
      retMsg := 'success';
      for rec01 in cur_01 loop
        sql0 := 'update pf_merchant_info set merchant_code=
        (select merchant_code from PF_MERCHANT_RELATION_INFO where private_merchant_id='||to_char(rec01.private_merchant_id)||')
        where merchant_id='||to_char(rec01.private_merchant_id);
        execute immediate sql0;
        merchantId := rec01.private_merchant_id;
        for rec02 in cur_02 loop
          sql0:='update pf_merchant_pay_info set pay_mode='||''''||rec02.pay_mode||''''||',pay_name='||''''||rec02.pay_name||''''||
          ' where merchant_id='||merchantId||' and pay_center='||''''||rec02.pay_center||'''';
          execute immediate sql0;
        end loop;
      end loop;
      commit;
       Exception
        When others then
          retCode := SQLCODE;
          retMsg := SUBSTR(SQLERRM, 1, 200);
          rollback;
end update_merchant_code;






/

