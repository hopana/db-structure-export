create function func_refund_compare(merchantCodeLen in number,startDate in varchar2,endDate in varchar2) RETURN varchar2 is
    msg varchar(1024);
    sql0 varchar(1024);
begin
      msg:='success';
      update pf_cft_refund_info set merchant_code=substr( order_id,0,merchantCodeLen);
      update pf_wft_refund_info set merchant_code=substr( order_id,0,merchantCodeLen);
      --删除商户订单表中的数据（分三步删除，为了防止删除跨天抹平的订单）
      --删除威富通多余订单
      delete from PF_MERCHANT_REFUND_INFO where to_char(w_order_refund_time,'yyyy-MM-dd') between startDate and endDate and c_refund_fee is null;
      --删除财付通多余订单
      delete from PF_MERCHANT_REFUND_INFO where to_char(c_refund_time,'yyyy-MM-dd') between startDate and endDate and w_refund_fee is null;
      --删除两者都有的订单
      delete from PF_MERCHANT_REFUND_INFO where to_char(c_refund_time,'yyyy-MM-dd') between startDate and endDate and to_char(w_order_refund_time,'yyyy-MM-dd') between startDate and endDate;
      update PF_WFT_REFUND_INFO w set pay_name = (select pay_name from pf_pay_center s where w.pay_type = s.pay_mode);

      --先将威富通的订单表导入到商户订单表中
      sql0:='insert into PF_MERCHANT_REFUND_INFO(id,w_refund_no,w_order_id,w_merchant_code,w_total_fee,w_refund_fee,w_order_create_time,
      w_refund_status,w_order_status,w_transaction_refund_no,w_transaction_Id,w_merchant_refund_no,w_pay_type,w_pay_name,w_order_refund_time,update_version)
      select PF_MERCHANT_REFUND_INFO_SEQ.nextval,refund_no,order_id,merchant_code,total_fee,refund_fee,order_create_time,
      refund_status,order_status,transaction_refund_no,
      transaction_Id,merchant_refund_no,pay_type,pay_name,order_refund_time,0 from PF_WFT_REFUND_INFO';
      execute immediate sql0;

      --将财付通的订单数据插入到订单表
      merge into PF_MERCHANT_REFUND_INFO a using pf_cft_refund_info b
      on (a.w_refund_no = b.refund_no)
      when matched then
       update set a.c_refund_no=b.refund_no,a.c_order_id=b.order_id,a.c_refund_time=b.refund_time,
       a.c_third_merchant_code=b.third_merchant_code,a.c_child_merchant_code=b.child_merchant_code,a.c_transaction_refund_no=b.transaction_refund_no,
       a.c_transaction_Id=b.transaction_Id,
       a.c_pay_type=b.pay_type,a.c_trade_status=b.trade_status,a.c_coin_type=b.coin_type,a.c_total_fee=b.total_fee,
       a.c_refund_fee=b.refund_fee,a.c_refund_benefit_fee=b.refund_benefit_fee,a.c_refund_cost_rate=b.refund_cost_rate,a.c_merchant_code=b.merchant_code
      WHEN NOT MATCHED THEN INSERT(id,c_refund_time,c_refund_no,c_order_id,c_third_merchant_code,c_child_merchant_code,c_transaction_refund_no,c_transaction_id,c_pay_type,
                c_trade_status,c_coin_type,c_total_fee,c_refund_fee,c_refund_benefit_fee,c_refund_cost_rate,c_merchant_code,update_version)values(PF_MERCHANT_REFUND_INFO_seq.nextval,
      b.refund_time,b.refund_no,b.order_id,b.third_merchant_code,b.child_merchant_code,
      b.transaction_refund_no,b.transaction_id,b.pay_type,b.trade_status,b.coin_type,b.total_fee,b.refund_fee,b.refund_benefit_fee,
      b.refund_cost_rate,b.merchant_code,0);

       --更新商户费率
      update PF_MERCHANT_REFUND_INFO a  set pay_rate=(select c.pay_rate from pf_merchant_info b
      left join pf_merchant_pay_info c on b.merchant_id=c.merchant_id
      where c.pay_mode=  a.c_pay_type and b.merchant_code = a.c_merchant_code) where to_char(c_refund_time,'yyyy-MM-dd') between startDate and endDate;
      --更新商户手续费
      update PF_MERCHANT_REFUND_INFO set merchant_fee=c_refund_fee*pay_rate/1000 where to_char(c_refund_time,'yyyy-MM-dd') between startDate and endDate;
      --更新状态
      update PF_MERCHANT_REFUND_INFO set compare_result='RET000' where w_refund_fee/100=c_refund_fee and to_char(c_refund_time,'yyyy-MM-dd') between startDate and endDate;
      update PF_MERCHANT_REFUND_INFO set compare_result='RET003' where w_refund_fee/100<>c_refund_fee and to_char(c_refund_time,'yyyy-MM-dd') between startDate and endDate;
      update PF_MERCHANT_REFUND_INFO set compare_result='RET002' where w_refund_fee is null and to_char(c_refund_time,'yyyy-MM-dd') between startDate and endDate;
      update PF_MERCHANT_REFUND_INFO set compare_result='RET001' where c_refund_fee is null and to_char(w_order_refund_time,'yyyy-MM-dd') between startDate and endDate;

      return msg;
      Exception
      When others then
        msg := SUBSTR(SQLERRM, 1, 200);
        rollback;
        return msg;
end func_refund_compare;






/

