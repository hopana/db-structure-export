create function func_order_compare(merchantCodeLen in number,startDate out varchar2,endDate out varchar2) RETURN varchar2 is
    msg varchar(1024);
    sql0 varchar(1024);
    w_startDate varchar(32);
    w_endDate varchar(32);
    c_startDate varchar(32);
    c_endDate varchar(32);
begin
      msg:='success';
      --先取订单的前10位做为商户号
      update pf_cft_order_info set merchant_code=substr( order_id,0,merchantCodeLen);
      update pf_wft_order_info set merchant_code=substr( order_id,0,merchantCodeLen);
      select min(to_char(order_trade_time,'yyyy-MM-dd')) ,max(to_char(order_trade_time,'yyyy-MM-dd')) into w_startDate,w_endDate from PF_WFT_ORDER_INFO;
      select min(to_char(trade_time,'yyyy-MM-dd')) ,max(to_char(trade_time,'yyyy-MM-dd')) into c_startDate,c_endDate from PF_CFT_ORDER_INFO;
      if(w_startDate<>c_startDate or w_endDate<>c_endDate)then
          msg:='威富通和财付通对账文件日期不匹配，请确认文件是否正确';
          return msg;
      end if;
      startDate:=c_startDate;
      endDate:=c_endDate;
      --删除商户订单表中的数据（分三步删除，为了防止删除跨天抹平的订单）
      --删除威富通多余订单
      delete from PF_MERCHANT_ORDER_INFO where to_char(w_order_trade_time,'yyyy-MM-dd') between startDate and endDate and c_total_fee is null;
      --删除财付通多余订单
      delete from PF_MERCHANT_ORDER_INFO where to_char(c_trade_time,'yyyy-MM-dd') between startDate and endDate and w_total_fee is null;
      --删除两者都有的订单
      delete from PF_MERCHANT_ORDER_INFO where to_char(c_trade_time,'yyyy-MM-dd') between startDate and endDate and to_char(w_order_trade_time,'yyyy-MM-dd') between startDate and endDate;
      update PF_WFT_ORDER_INFO w set pay_name = (select pay_name from pf_pay_center s where w.pay_type = s.pay_mode);

      --先将威富通的订单表导入到商户订单表中
      sql0:='insert into PF_MERCHANT_ORDER_INFO(id,w_merchant_code,w_order_id,w_merchant_name,w_merchant_order_id,w_total_fee,w_refund_fee,
      w_trade_status,w_center_id,w_order_time,w_order_trade_time,w_transaction_id,w_pay_type,w_pay_name,update_version)
      select PF_MERCHANT_ORDER_INFO_SEQ.nextval,merchant_code,order_id,merchant_name,merchant_order_id,total_fee,refund_fee,trade_status,center_id,order_time,order_trade_time,
      transaction_id,pay_type,pay_name,0 from PF_WFT_ORDER_INFO';
      execute immediate sql0;
      --将财付通的订单数据插入到订单表
      merge into PF_MERCHANT_ORDER_INFO a using pf_cft_order_info b
      on (a.w_order_id=b.order_id)
      when matched then
       update set a.c_trade_time=b.trade_time,a.c_third_merchant_code=b.third_merchant_code,a.c_child_merchant_code=b.child_merchant_code,
       a.c_transaction_id=b.transaction_id,a.c_order_id=b.order_id,a.c_pay_type=b.pay_type,a.c_trade_status=b.trade_status,
       a.c_coin_type=b.coin_type,a.c_total_fee=b.total_fee,a.c_total_benefit_fee=b.total_benefit_fee,a.c_cost_rate=b.cost_rate,
       a.c_merchant_code=b.merchant_code
      WHEN NOT MATCHED THEN INSERT(id,c_trade_time,c_third_merchant_code,c_child_merchant_code,c_transaction_id,c_order_id,
      c_pay_type,c_trade_status,c_coin_type,c_total_fee,c_total_benefit_fee,c_cost_rate,c_merchant_code)values(PF_MERCHANT_ORDER_INFO_seq.nextval,
      b.trade_time,b.third_merchant_code,b.child_merchant_code,b.transaction_id,b.order_id,
      b.pay_type,b.trade_status,b.coin_type,b.total_fee,b.total_benefit_fee,b.cost_rate,b.merchant_code);

      --更新商户费率
      update PF_MERCHANT_ORDER_INFO a  set pay_rate=(select c.pay_rate from pf_merchant_info b
      left join pf_merchant_pay_info c on b.merchant_id=c.merchant_id
      where c.pay_mode=  a.c_pay_type and b.merchant_code = a.c_merchant_code) where a.c_merchant_code is not null and to_char(c_trade_time,'yyyy-MM-dd') between startDate and endDate;

      --更新商户手续费
      update PF_MERCHANT_ORDER_INFO set merchant_fee=c_total_Fee*pay_rate/1000 where c_total_fee is not null and to_char(c_trade_time,'yyyy-MM-dd') between startDate and endDate;
      --更新状态
      update PF_MERCHANT_ORDER_INFO set compare_result='RET000' where w_total_Fee/100=c_total_Fee and (w_total_Fee is not null and c_total_Fee is not null) and to_char(c_trade_time,'yyyy-MM-dd') between startDate and endDate;

      update PF_MERCHANT_ORDER_INFO set compare_result='RET003' where w_total_Fee/100<>c_total_Fee and (w_total_Fee is not null and c_total_Fee is not null) and to_char(c_trade_time,'yyyy-MM-dd') between startDate and endDate;

      update PF_MERCHANT_ORDER_INFO set compare_result='RET002' where w_total_Fee is null and to_char(c_trade_time,'yyyy-MM-dd') between startDate and endDate;

      update PF_MERCHANT_ORDER_INFO set compare_result='RET001' where c_total_Fee is null and to_char(w_order_trade_time,'yyyy-MM-dd') between startDate and endDate;

      return msg;
       Exception
        When others then
          msg := SUBSTR(SQLERRM, 1, 200);
          rollback;
          return msg;
end func_order_compare;






/

