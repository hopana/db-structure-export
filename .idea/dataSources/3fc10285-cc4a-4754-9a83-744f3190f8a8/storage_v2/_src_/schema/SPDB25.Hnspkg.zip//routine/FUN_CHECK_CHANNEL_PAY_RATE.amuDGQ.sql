create function fun_check_channel_pay_rate(merchantId in number,merchantChannelId in varchar2,
 merchantRate in number,channelId in varchar2,payMode in varchar2,
 rateType in varchar2,rate in number) RETURN varchar2 is
    tmpChannelId varchar2(32);
    tmpRateType varchar2(6);
    tmpRate NUMBER(20,6);
    channelRate number(20,6);
    iCount number(11);
    costRate number(20,6);
    parentInviteCode varchar2(32);
    msg varchar(1024);
    merchantName varchar2(128);
begin
    tmpRateType:='RAT001';
    tmpRate:=0.0;
    if(merchantChannelId != channelId)then
       --不是本渠道则要查询
       select count(1) into iCount from pf_channel_rate_info where channel_id = merchantChannelId and pay_mode = payMode;
       if(iCount>0)then
          select rate_type,rate into tmpRateType,tmpRate from pf_channel_rate_info where channel_id = merchantChannelId and pay_mode = payMode;
       end if;
    else
       tmpRateType:=rateType; --如果是本渠道则不检查
       tmpRate:=rate;
    end if;
    select merchant_name into merchantName from pf_merchant_info where merchant_id = merchantId;
    if(tmpRateType='RAT001')then
      channelRate :=  merchantRate - tmpRate;--商户费率-渠道费率
      if(channelRate<0)then
         msg:='固定费率下,渠道ID：'||merchantChannelId||'对应的渠道费率为'||tmpRate||',不能小于' || merchantName || '的商户费率' || merchantRate;
         return msg;
      end if;
    else
      if(merchantRate<tmpRate)then
         msg:='浮动费率下,渠道ID：'||merchantChannelId||'对应的渠道费率为'||tmpRate||',不能大于' || merchantName || '的商户费率' || merchantRate;
         return msg;
      end if;
      channelRate := tmpRate;
    end if;
    select parent_invite_code into parentInviteCode from pf_channel_info where channel_id=merchantChannelId;
    if(parentInviteCode='0')then
      return 'ok';
    end if;
    select channel_id into tmpChannelId from pf_channel_info
    where invite_code=parentInviteCode;
    while 1=1 loop
       if(parentInviteCode='0')then
          --是顶级渠道则要进行对渠道的成本进行查询后进行判断
          select cost_rate into costRate from pf_merchant_pay_info where merchant_id=merchantId and pay_mode = payMode;
          --channelRate :=  channelRate - costRate;--渠道费率-商户成本费率
          if(channelRate < costRate)then
             msg:='渠道ID：'||merchantChannelId||'对应的渠道费率为'||channelRate||'小于当前设定的费率' || costRate;
             return msg;
          end if;
          exit;--如果找到顶级渠道则退出
       end if;

       if(tmpChannelId<>channelId)then
          select count(1) into iCount from pf_channel_rate_info where channel_id = tmpChannelId and pay_mode = payMode ;
          if(iCount>0)then
             select rate_type,rate into tmpRateType,tmpRate from pf_channel_rate_info where channel_id = tmpChannelId and pay_mode = payMode;
          end if;
       else
          tmpRateType:=rateType; --如果是本渠道则不检查
          tmpRate:=rate;
       end if;
       if(tmpRateType='RAT001')then
          channelRate :=  channelRate - tmpRate;--商户费率-渠道费率
          if(channelRate<0)then
                msg:='固定费率下,渠道ID：'||merchantChannelId||'对应的渠道费率为'||tmpRate||',不能小于' || merchantName || '的商户费率' || merchantRate;
              --msg:='渠道ID：'||merchantChannelId||'对应的商户费率为'||merchantRate||'小于当前设定的费率';
             return msg;
          end if;
       else
          if(channelRate<tmpRate)then
              msg:='浮动费率下,渠道ID：'||merchantChannelId||'对应的渠道费率为'||tmpRate||',不能大于' || merchantName || '的商户费率' || merchantRate;
              --msg:='渠道ID：'||merchantChannelId||'对应的商户费率为'||merchantRate||'小于当前设定的费率';
             return msg;
          end if;
          channelRate := tmpRate;
       end if;
        --下面开始父渠道的查询
       select channel_id,parent_invite_code into tmpChannelId,parentInviteCode from pf_channel_info
       where invite_code = parentInviteCode;
    end loop;
    return 'ok';
end fun_check_channel_pay_rate;






/

