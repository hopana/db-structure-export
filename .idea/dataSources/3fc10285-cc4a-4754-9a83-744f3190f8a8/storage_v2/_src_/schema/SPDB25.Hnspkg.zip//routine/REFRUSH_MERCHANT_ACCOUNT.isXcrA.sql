create procedure refrush_merchant_account(retCode out Integer,
                                                     retMsg  out varchar2,cleanDate in varchar2,
                                                     cleanDateEnd in varchar2)
  Authid CURRENT_USER is
  sql0           varchar2(512);
  bankNumber     varchar(32);
  --contactLine    varchar(12); --行别、联行号
  accountName    VARCHAR2(128); --账号名称
  --branchbankName varchar(256);
  payeeAddress   varchar(128); --地址
  --provinceCode   varchar(6);
  --cityCode       varchar(6);
  --provinceName   varchar(255);
  --cityName       varchar(255);
  --bankName       varchar(255);
  md5_str        varchar2(2000);
  --商户账号信息更新
  CURSOR cur_01 IS
    select merchant_code, account, pay_mode, md5_str
      from pf_merchant_cleaning_info
     where flag not in ('Y', 'y')
       and is_channel = 'CLR002'
       AND clean_status = 'CLEAN_007'
       AND error_status = 'ERROR_002'
       and to_char(cleaning_date,'yyyy-MM-dd') between cleanDate and cleanDateEnd ;
  /**CURSOR cur_02 IS
    select merchant_code, account,md5_str
      from pf_merchant_cleaning_info
     where flag not in ('Y', 'y')
       and is_channel = 'CLR001' and to_char(cleaning_date,'yyyy-MM-dd') between cleanDate and cleanDateEnd ;
**/
begin
  retCode := 0;
  retMsg  := 'success';
  --更新账号信息
  for rec01 in cur_01 loop
    begin
      sql0 := 'select a.bank_number,a.account_name
        from pf_merchant_pay_info a
         where merchant_id=
        (select merchant_id from pf_merchant_info where merchant_code=' || '''' ||
              rec01.merchant_code || '''' || ')
        and pay_mode=' || '''' || rec01.pay_mode || '''';
      execute immediate sql0
        into bankNumber, accountName;
    exception
      when NO_DATA_FOUND then
        retCode := -1;
        retMsg  := '没有在商户支付表找到商户号为:' || rec01.merchant_code || '和支付方式为:' ||
                   rec01.pay_mode || '的账号信息';
        rollback;
        exit;
    end;
    /**select name
      into provinceName
      from shop_city_area
     where region_id = provinceCode;
    select name
      into cityName
      from shop_city_area
     where region_id = cityCode;
**/
    payeeAddress := bankNumber || accountName;
    md5_str      := md5(payeeAddress);

    if (md5_str <> rec01.md5_str) then
      sql0 := 'update pf_merchant_cleaning_info set is_update = 1,md5_str = ''' || md5_str || ''''
               || ',account=' || '''' ||
              bankNumber || ''',account_name=' || '''' ||
              accountName || '''' || ' where merchant_code=' || '''' ||
              rec01.merchant_code || '''' || 'and pay_mode=' || '''' ||
              rec01.pay_mode || ''' and to_char(cleaning_date,''yyyy-MM-dd'') between '''  || cleanDate || ''' and ''' || cleanDateEnd || '''';
      execute immediate sql0;
    end if;
  end loop;

  /**for rec02 in cur_02 loop
    begin
      sql0 := 'select a.contact_line,a.account_name,a.bank_number,b.bank_name,a.province,a.city,a.bank_name
            from pf_channel_account_info a left join pf_bank_info b on a.bank_number_code=b.bank_number_code
            where channel_id=' || '''' || rec02.merchant_code || '''';
      execute immediate sql0
        into contactLine, accountName, bankNumber, bankName, provinceCode, cityCode, branchbankName;
    exception
      when NO_DATA_FOUND then
        retCode := -1;
        retMsg  := '没有在渠道账号表找到渠道号为' || rec02.merchant_code || '的账号信息';
        rollback;
        exit;
    end;
    select name
      into provinceName
      from shop_city_area
     where region_id = provinceCode;
    select name
      into cityName
      from shop_city_area
     where region_id = cityCode;
    payeeAddress := bankName || provinceName || cityName || branchbankName;
    md5_str      := md5(contactLine || bankNumber || accountName ||
                        payeeAddress);
    if (md5_str <> rec02.md5_str) then
      sql0 := 'update pf_merchant_cleaning_info set is_update = 1,md5_str=''' || md5_str || ''',contact_line=' || '''' ||
              contactLine || '''' || ',' || 'account=' || '''' ||
              bankNumber || '''' || ',' || 'account_name=' || '''' ||
              accountName || '''' || ',' || 'bank_name=' || '''' ||
              payeeAddress || '''' || ' where merchant_code=' || '''' ||
              rec02.merchant_code || ''' and to_char(cleaning_date,''yyyy-MM-dd'') between '''  || cleanDate || ''' and ''' || cleanDateEnd || '''';
      execute immediate sql0;
    end if;
  end loop;
**/
  commit;
Exception
  When others then
    retCode := SQLCODE;
    retMsg  := SUBSTR(SQLERRM, 1, 200);
    rollback;
end refrush_merchant_account;






/

