create procedure check_merchant_pay_rate(merchantId in number,centerId in varchar2,
payRate in number,costRate in number,retCode out Integer,retMsg out varchar2 ) Authid CURRENT_USER is
      --下次统一要把商户对应的虚拟还是实体的要加进来，现在这里就不加了
      sql0 varchar2(1024) ;
      channelId varchar2(32);
      parentInviteCode varchar2(32);
      execRate number(20,6);--渠道的执行费率
      tmpRate number(20,6);
      tmpRateType varchar(6);
      payMode varchar(64);
begin
      retCode:=0;
      retMsg:='ok';
      execRate:=0;
      select pay_mode into payMode from pf_pay_center where center_id=to_number(centerId);
      select channel_id into channelId  from pf_merchant_info where merchant_id=merchantId;
      select parent_invite_code into parentInviteCode from pf_channel_info where channel_id=channelId;
      while 1=1 loop
        if(parentInviteCode='0')then
           execRate:=execRate+costRate;--顶级渠道则取成本费率
           exit;
        end if;
        begin
           sql0:='select rate_type,rate from pf_channel_rate_info where channel_id='''||channelId||''' and pay_mode='''||payMode||'''';
           execute immediate sql0 into tmpRateType,tmpRate;
           exception
              when NO_DATA_FOUND then
                tmpRateType:='RAT001';--如果没有配置设置一个默认值
                tmpRate:=0;
        end;
        execRate := execRate+tmpRate;
        if(tmpRateType='RAT002')then--浮动
          exit;--到浮动费率时则停止，总费率则为下面的浮动费率+下面的固定费率
        end if;
        select channel_id,parent_invite_code into channelId,parentInviteCode from pf_channel_info where  invite_code=parentInviteCode;--查找上一级的渠道
      end loop;
      if(execRate>payRate)then
        retCode:=1;
        retMsg:='该商户的费率必须大于:'||execRate||'‰';
      end if;
end check_merchant_pay_rate;






/

