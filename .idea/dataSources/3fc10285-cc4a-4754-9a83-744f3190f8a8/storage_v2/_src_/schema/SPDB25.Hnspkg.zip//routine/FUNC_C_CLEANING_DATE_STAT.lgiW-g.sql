create function func_c_cleaning_date_stat(payDate      in Date,
                                                   cleanInterval in number,
                                                   bankPrefix   in varchar2,
                                                   cleaningDate out varchar2)
  RETURN varchar2 is
  msg                varchar(1024);
  iCount             number(11);
  tmpCleaningDate    Date; --下一次循环的开始
  tmpCleaningEndDate Date; --下一次循环的结束
  endNum             number(11);
begin
  msg    := 'success';
  --渠道计算清分日期
  tmpCleaningDate := payDate + cleanInterval;
  endNum          := cleanInterval;
  select count(1)
    into iCount
    from pf_holidays w
   where to_char(w.holiday_date, 'yyyy-MM-dd') between
         to_char(payDate + 1, 'yyyy-MM-dd') and
         to_char(tmpCleaningDate, 'yyyy-MM-dd')
     and w.bank_prefix = bankPrefix;
  if (iCount > 0) then
    tmpCleaningEndDate := tmpCleaningDate + iCount;
    endNum             := endNum + iCount;
    while 1 = 1 loop
      select count(1)
        into iCount
        from pf_holidays w
       where to_char(w.holiday_date, 'yyyy-MM-dd') between
             to_char(tmpCleaningDate+1, 'yyyy-MM-dd') and
             to_char(tmpCleaningEndDate, 'yyyy-MM-dd');
      if (iCount > 0) then
        tmpCleaningDate    := tmpCleaningEndDate + 1;
        tmpCleaningEndDate := tmpCleaningDate;
        endNum             := endNum + iCount;
        tmpCleaningDate := tmpCleaningDate - 1;
      else
        exit;
      end if;
    end loop;
  end if;

  select to_char(payDate + endNum, 'yyyy-MM-dd')
    into cleaningDate
    from dual;
  return msg;
Exception
  When others then
    msg := SUBSTR(SQLERRM, 1, 200);
    rollback;
    return msg;
end func_c_cleaning_date_stat;






/

