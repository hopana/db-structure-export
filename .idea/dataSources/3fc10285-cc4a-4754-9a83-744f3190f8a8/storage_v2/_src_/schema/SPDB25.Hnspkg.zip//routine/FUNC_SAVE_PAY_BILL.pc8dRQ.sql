create function func_save_pay_bill(startDate in varchar2,endDate in varchar2) RETURN varchar2 is
    msg varchar(1024);
    sql0 varchar(1024);
begin
      msg:='success';

      --根据账对平的商户和支付方式进行汇总
      --插入历史表
      sql0:='insert into PF_PAY_DAY_BILL_HISTORY(pay_id,pay_date,merchant_code,pay_mode,pay_name,total_count,total_fee,
        refund_count,refund_fee,total_netfee,rate,cost_rate,third_fee,merchant_fee,merchant_remit_fee,update_version)
        select PF_PAY_DAY_BILL_HISTORY_SEQ.Nextval,pay_date,merchant_code,
        pay_mode,pay_name,total_count,total_fee,refund_count,refund_fee,total_netfee,rate,cost_rate,third_fee,merchant_fee,
        merchant_remit_fee,0
        from PF_PAY_DAY_BILL';
        execute immediate sql0;
        sql0:='update PF_PAY_DAY_BILL_HISTORY set a_third_fee = round(total_netfee*cost_rate/1000,2),a_merchant_fee= round(total_netfee*rate/1000,2),a_merchant_remit_fee=round(total_netfee-round(total_netfee*rate/1000,2),2)
         where to_char(pay_date,''yyyy-MM-dd'') between '||''''||startDate||''''||' and '||''''||endDate||'''';
        execute immediate sql0;
        return msg;
         Exception
          When others then
            msg := SUBSTR(SQLERRM, 1, 200);
            rollback;
            return msg;
end func_save_pay_bill;






/

