create function func_minus(data1 in number, data2 in number) return  number is
  returnVal number(20) ;
  v_data_1 number(20);
  v_data_2 number(20);
begin
  if(data1 is null)then
           v_data_1 := 0;
  end if;
  if(data2 is null)then
           v_data_2 := 0;
  end if;
  return v_data_1 - v_data_2;
end func_minus;






/

