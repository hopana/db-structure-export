create procedure GEN_SEQ is
  /**sql0 varchar2(512);
  maxNum number(20);**/
  retCode    varchar2(2000);
  retMsg     varchar2(2000); /**
  v_var  varchar2(2000);
  CURSOR cur_01 IS
      select * from  user_objects where object_type = 'TABLE';**/
  row_result varchar2(1024);
  selectsql  varchar2(1024);
  qrycursor  SYS_REFCURSOR;
  txt_handle UTL_FILE.file_type;
begin
  /**delete from tmp_seq;
  for rec01 in cur_01 loop
    begin
      sql0 := 'select nvl(max(id),0) from ' || rec01.object_name;
      execute immediate sql0 into maxNum;
      if(maxNum is null)then
                maxNum := 0;
      end if;
      sql0 := 'select 1 from user_objects where object_type = ''SEQUENCE'' and object_name
      = ''' || rec01.object_name || '_SEQ''';
      execute immediate sql0;
      v_var := 'drop sequence ' || rec01.object_name || '_SEQ ;' ;

      sql0 := 'insert into tmp_seq(seq_var) values(''' || v_var || ''')';
      execute immediate sql0;
      v_var :=  'create sequence ' ||
      rec01.object_name || '_SEQ start with ' || (maxNum + 10) || ';';

      sql0 := 'insert into tmp_seq(seq_var) values(''' || v_var || ''')';
      execute immediate sql0;
      --commit;
      exception
        when OTHERS then
          retCode := SQLCODE;
          retMsg  := SUBSTR(SQLERRM, 1, 200);
          continue;
      end;
   end loop;
   commit;**/
  selectsql  := ' select ORDER_ID||''  ''||MERCHANT_CODE||''  ''||MERCHANT_NAME||''  ''||MERCHANT_ORDER_ID||''  ''||TOTAL_FEE||''  ''||REFUND_FEE||''  ''||TRADE_STATUS||''  ''||CENTER_ID||''  ''||TRANSACTION_ID||''  ''||PAY_TYPE||''  ''||PAY_NAME from pf_wft_order_info ';
  txt_handle := UTL_FILE.FOPEN('D_OUTPUT', 'a.txt', 'w');
  open qrycursor for selectsql;
  loop
    fetch qrycursor
      into row_result;
    exit when qrycursor%notfound;
    UTL_FILE.PUT_LINE(txt_handle, row_result);
  end loop;
  --关闭游标
  close qrycursor;
  UTL_FILE.FCLOSE(txt_handle);
exception
  when OTHERS then
    retCode := SQLCODE;
    retMsg  := SUBSTR(SQLERRM, 1, 200);
    rollback;
end GEN_SEQ;






/

