create procedure check_SEQ(retCode out Integer,
                                      retMsg  out varchar2) is
  sql0      varchar2(512);
  maxNum    number(20);
  iCount    number(10);
  currNum   number(20);
  dataType  varchar2(64);

begin
  retMsg := 'SUCCESS';
  delete from tmp_seq;
  for rec01 in (select object_name
                  from user_objects
                 where object_type = 'TABLE'
                   and object_name != 'TMP_SEQ') loop
    select count(1)
      into iCount
      from user_objects w
     where w.object_type = 'SEQUENCE'
       and w.OBJECT_NAME = 'SEQ_' || rec01.object_name;
    if (iCount > 0) then
      --找到主键列名,有多个主键
      for rec02 in (select cu.COLUMN_NAME
                      from user_cons_columns cu, user_constraints au
                     where cu.constraint_name = au.constraint_name
                       and au.constraint_type = 'P'
                       and au.table_name = rec01.object_name) loop

        select w.DATA_TYPE
          into dataType
          from user_tab_cols w
         where w.COLUMN_NAME = rec02.column_name
           and w.TABLE_NAME = rec01.object_name;
        if ('NUMBER' = dataType) then
          --表中最大值
          sql0 := 'select max(' || rec02.column_name || ') from ' ||
                  rec01.object_name;
          execute immediate sql0
            into maxNum;
          if (maxNum is null) then
            maxNum := 0;
          end if;
          --序列下个值
          sql0 := 'select SEQ_' || rec01.object_name || '.nextval from dual';
          execute immediate sql0
            into currNum;
          if (currNum is null) then
            currNum := 0;
          end if;

          if (maxNum >= currNum) then
            sql0 := 'insert into tmp_seq(seq_var) values(''alter sequence SEQ_' ||
                    rec01.object_name || ' Increment By ' ||
                    (maxNum - currNum + 100) || ' ;select SEQ_' ||
                    rec01.object_name ||
                    '.nextval from dual;alter sequence SEQ_' ||
                    rec01.object_name || ' Increment By 1;'')';
            execute immediate sql0;
          end if;
        end if;
      end loop;
    end if;
  end loop;
  commit;
exception
  when OTHERS then
    retCode := SQLCODE;
    retMsg  := SUBSTR(SQLERRM, 1, 200);
    rollback;
end check_SEQ;





/

