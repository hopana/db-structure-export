create function func_cleaning_date_stat(payDate      in Date,
                                                   merchantCode in varchar2,
                                                   payMode      in varchar2,
                                                   payName      in varchar2,
                                                   bankPrefix   in varchar2,
                                                   cleaningDate out varchar2)
  RETURN varchar2 is
  msg                varchar(1024);
  iCount             number(11);
  cleanInterval      number(20);
  tmpCleaningDate    Date; --下一次循环的开始
  tmpCleaningEndDate Date; --下一次循环的结束
  endNum             number(11);
begin
  msg    := 'success';
  select w.clean_interval
    into cleanInterval
    from pf_merchant_pay_info w
    left join pf_merchant_info a
      on w.merchant_id = a.merchant_id
   where a.merchant_code = merchantCode
     and w.pay_mode = payMode;
  tmpCleaningDate := payDate + cleanInterval;
  endNum          := cleanInterval;
  select count(1)
    into iCount
    from pf_holidays w
   where to_char(w.holiday_date, 'yyyy-MM-dd') between
         to_char(payDate + 1, 'yyyy-MM-dd') and
         to_char(tmpCleaningDate, 'yyyy-MM-dd')
     and w.bank_prefix = bankPrefix;
  if (iCount > 0) then
    tmpCleaningEndDate := tmpCleaningDate + iCount;
    endNum             := endNum + iCount;
    while 1 = 1 loop
      select count(1)
        into iCount
        from pf_holidays w
       where to_char(w.holiday_date, 'yyyy-MM-dd') between
             to_char(tmpCleaningDate+1, 'yyyy-MM-dd') and
             to_char(tmpCleaningEndDate, 'yyyy-MM-dd');
      if (iCount > 0) then
        tmpCleaningDate    := tmpCleaningEndDate + 1;
        tmpCleaningEndDate := tmpCleaningDate;
        endNum             := endNum + iCount;
        tmpCleaningDate := tmpCleaningDate - 1;
      else
        exit;
      end if;
    end loop;
  end if;

  select to_char(payDate + endNum, 'yyyy-MM-dd')
    into cleaningDate
    from dual;
  return msg;
Exception
  when NO_DATA_FOUND then
    msg := '该商户号为:' || merchantCode || '的该种支付类型:' || payMode || '不存在!';
    rollback;
    return msg;
  When others then
    msg := SUBSTR(SQLERRM, 1, 200);
    rollback;
    return msg;
end func_cleaning_date_stat;






/

