create function func_merchant_clearing(startDate       in varchar2,
                                                  endDate         in varchar2)
 RETURN varchar2 is

  msg              varchar(1024);
  compactCode      varchar(32);
  bankNumber       varchar(32);
  contactLine      varchar(32); --行别、联行号
  accountName      VARCHAR2(128); --账号名称
  bankName         varchar(256); --收款行名称
  sql0             varchar(1024);
  total_netfee     number(20, 2); --交易净额
  amount           number(20, 2);
  amount1          number(20, 2);
  iCount           number(11);
  merchantName     varchar(512);
  total_count      number(20); --交易笔数
  third_fee        number(20, 2); --财付通手续费
  is_bank          number(1); --是否行内帐号               1=行内 2=行外
  account_type     varchar2(128); --帐号类型
  pay_name         varchar2(128);
  cleanDate        varchar2(128);
  md5_str          varchar2(2000);
  enterpriseSerial varchar2(64);
  cleaningMode     varchar2(6);
  CURSOR cur_01 IS
    select pay_date,
           pay_name,
           merchant_code,
           pay_mode,
           rate,
           merchant_fee,
           a_merchant_fee,
           third_fee,
           a_third_fee,
           sum(total_count + refund_count) as total_count,
           SUM(round(total_netfee,2)) as total_netfee
      from PF_PAY_DAY_BILL_history
      where to_char(pay_date,'yyyy-MM-dd') between startDate and endDate
      group by pay_date,
           pay_name,
           merchant_code,
           pay_mode,
           rate,
           merchant_fee,
           a_merchant_fee,
           third_fee,
           a_third_fee;
begin
  --清分日期得改成T+N计算
  msg := 'success';
  begin
    sql0 := 'select interface_address from pf_interface_info where interface_code=''CLEANING_MODE''';
    execute immediate sql0
      into cleaningMode;
  exception
    when NO_DATA_FOUND then
      msg := 'Can''t find cleaning mode,please configure CLEANING_MODE!';
      return msg;
  end;

  for rec01 in cur_01 loop
    if (cleaningMode = 'CLR001') then
      amount    := rec01.total_netfee - rec01.a_merchant_fee;
      --third_fee := rec01.a_third_fee;
    else
      amount    := rec01.total_netfee - rec01.merchant_fee;
      --third_fee := rec01.third_fee;
    end if;
    select count(1)
      into iCount
      from pf_merchant_cleaning_info
     where to_char(pay_date, 'yyyy-MM-dd') =
           to_char(rec01.pay_date, 'yyyy-MM-dd')
       and merchant_code = rec01.merchant_code
       and pay_mode = rec01.pay_mode;
    --如果不存在则需要插入
    if (iCount = 0) then
      begin
        sql0 := 'select b.bank_name,a.contact_line,a.is_bank,a.account_type,a.bank_number,a.account_name
        from pf_merchant_pay_info a left join pf_bank_info b on a.bank_number_code = b.bank_number_code
         where merchant_id=
        (select merchant_id from pf_merchant_info where merchant_code=' || '''' ||
                rec01.merchant_code || '''' || ')
        and pay_mode=' || '''' || rec01.pay_mode || '''';
        execute immediate sql0
          into bankName, contactLine, is_bank, account_type, bankNumber, accountName;
      exception
        when NO_DATA_FOUND then
          msg := '没有在商户支付表找到商户号为:' || rec01.merchant_code || '和支付方式为:' ||
                 rec01.pay_mode || '的账号信息';
          return msg;
      end;

      if (amount is null) then
        amount := 0;
      end if;
      if (amount < 0) then
        select merchant_name
          into merchantName
          from pf_merchant_info
         where merchant_code = rec01.merchant_code;
        msg := 'Exception:merchantName:' || merchantName ||
               ' cleaning amount less then 0';
        exit;
      end if;
      if (amount = 0) then
        --等于0时不做修改
        continue;
      end if;
      SELECT rpad(round(dbms_random.value(1,
                                          (SYSDATE -
                                          TO_DATE('1970-1-1 8',
                                                   'YYYY-MM-DD HH24')) *
                                          86400000 +
                                          TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3),
                                                            'FF')))),
                  11,
                  0)
        into compactCode
        FROM DUAL;

      msg := func_cleaning_date_stat(rec01.pay_date,
                                     rec01.merchant_code,
                                     rec01.pay_mode,
                                     rec01.pay_name,
                                     'SPDB_GUANGZHOU',
                                     cleanDate);
      if (msg <> 'success') then
        return msg;
      end if;

      md5_str := md5(bankNumber || accountName);
      select sys_guid() into enterpriseSerial from dual;
      sql0 := 'insert into PF_MERCHANT_CLEANING_INFO(id,cleaning_date,pay_date,merchant_code,pay_mode,compact_code,account,amount,flag,
        account_name,is_channel,
        update_version,total_netfee,total_count,third_fee,pay_name,is_bank,account_type,clean_status,md5_str,is_update,enterprise_serial,contact_line,bank_name,remark)
        values(PF_MERCHANT_CLEANING_INFO_seq.nextval,to_date(''' ||
              cleanDate || ''',''yyyy-MM-dd''),' || '''' || rec01.pay_date || '''' || ',' || '''' ||
              rec01.merchant_code || '''' || ',' || '''' || rec01.pay_mode || '''' || ',' || '''' ||
              compactCode || '''' || ',' || '''' || bankNumber || '''' || ',' ||
              to_char(amount) || ',''X''' || ',''' || accountName ||
              ''',''CLR002'',0,' || to_char(rec01.total_netfee) || ',' ||
              rec01.total_count || ',' || to_char(rec01.third_fee) || ',''' ||
              rec01.pay_name || ''',' || is_bank || ',''' || account_type ||
              ''',''CLEAN_000'',''' || md5_str || ''',0,''' ||
              enterpriseSerial || ''',''' || contactLine || ''',''' ||
              bankName || ''',''移动支付' || to_char(rec01.pay_date,'yyyyMMdd') || ''')';
      execute immediate sql0;
    else
      --这里比对一下金额是否与之前清分的一致，如果不一致则抛出异常
      select amount
        into amount1
        from pf_merchant_cleaning_info
       where to_char(pay_date, 'yyyy-MM-dd') =
             to_char(rec01.pay_date, 'yyyy-MM-dd')
         and merchant_code = rec01.merchant_code
         and pay_mode = rec01.pay_mode;
      if (amount1 <> amount) then
        msg := 'merchant_code:' || rec01.merchant_code || ', pay_mode:' ||
               rec01.pay_mode || ',total_netfee:' ||
               to_char(rec01.total_netfee) || ',export data amount:' ||
               to_char(amount) || ', but cleaning amount is ' ||
               to_char(amount1);
        EXIT;
      end if;
    end if;
  end loop;
  if (msg <> 'success') then
    return msg;
  end if;
  return msg;
Exception
  When others then
    msg := SUBSTR(SQLERRM, 1, 200);
    rollback;
    return msg;
end func_merchant_clearing;






/

